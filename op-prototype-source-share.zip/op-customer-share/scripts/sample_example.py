"""Prints a route-consistent example occurrence for use in the presentation."""

from __future__ import annotations

import json
import os

from sig_mvp.database import create_client


def main() -> None:
    uri = os.environ["MONGO_URI"]
    with create_client(uri) as client:
        db = client["sigmvp"]
        for prefix in ("dissolve", "inject"):
            rows = list(db["baseline_occurrences"].find(
                {"doctors_sig": {"$regex": f"^{prefix} "}},
                {"ndc": 1, "doctors_sig": 1, "translated_sig": 1, "context": 1},
            ).limit(2))
            print(f"--- {prefix} ---")
            for row in rows:
                ctx = row.get("context") or {}
                print(json.dumps({
                    "ndc": row["ndc"],
                    "drug_name": ctx.get("drug_name"),
                    "drug_form": ctx.get("drug_form"),
                    "route": ctx.get("route"),
                    "doctors_sig": row["doctors_sig"],
                    "translated_sig": row["translated_sig"],
                }, indent=2))


if __name__ == "__main__":
    main()
