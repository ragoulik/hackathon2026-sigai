"""Reports corpus shape to explain why the two layouts retrieve different amounts."""

import collections
import json
import pathlib

data = pathlib.Path("data")
occ = [json.loads(line) for line in (data / "occurrences.jsonl").open(encoding="utf-8")]
vec = [json.loads(line) for line in (data / "sig_vectors.jsonl").open(encoding="utf-8")]

print(f"occurrences={len(occ)}  unique_sig_vectors={len(vec)}")

per_ndc = collections.Counter(o["ndc"] for o in occ)
vals = sorted(per_ndc.values())
print(f"distinct_ndcs={len(per_ndc)}  occ_per_ndc min={vals[0]} med={vals[len(vals) // 2]} max={vals[-1]}")

per_sig = collections.Counter(o["doctors_sig"] for o in occ)
svals = sorted(per_sig.values())
print(f"rows_per_unique_sig min={svals[0]} med={svals[len(svals) // 2]} max={svals[-1]}")

ndcs_per_sig = collections.defaultdict(set)
sigs_per_ndc = collections.defaultdict(set)
for o in occ:
    ndcs_per_sig[o["doctors_sig"]].add(o["ndc"])
    sigs_per_ndc[o["ndc"]].add(o["doctors_sig"])

nvals = sorted(len(v) for v in ndcs_per_sig.values())
print(f"ndcs_covered_per_unique_sig min={nvals[0]} med={nvals[len(nvals) // 2]} max={nvals[-1]}")
print(f"distinct_sigs_per_ndc={collections.Counter(len(v) for v in sigs_per_ndc.values())}")

# Baseline takes the top 200 occurrence rows globally, so the nearest few sigs fill the budget.
print(f"rows_consumed_by_top_2_sigs={sum(svals[-2:])}  baseline_k=200")
