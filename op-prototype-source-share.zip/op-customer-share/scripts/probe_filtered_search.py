"""Checks whether DocumentDB supports NDC-filtered vector search, the prefilter the customer's API uses.

Exits non-zero if filtering is unsupported or silently ignored, since that would
invalidate the baseline retrieval design before any data is generated.
"""

from __future__ import annotations

import json
import os
import sys

from sig_mvp.database import create_client

DB_NAME = "sigmvp"


def main() -> int:
    uri = os.environ.get("MONGO_URI")
    if not uri:
        print("MONGO_URI is not set", file=sys.stderr)
        return 2

    report: dict = {"filtered_search_supported": False}
    with create_client(uri) as client:
        db = client[DB_NAME]
        probe = db["baseline_occurrences"].find_one(
            {}, {"embeddings": 1, "ndc": 1}
        )
        if not probe:
            print("baseline_occurrences is empty", file=sys.stderr)
            return 2

        vector = probe["embeddings"]
        target_ndc = probe["ndc"]
        report["probe_ndc"] = target_ndc

        unfiltered = list(db["baseline_occurrences"].aggregate([
            {"$search": {"cosmosSearch": {"vector": vector, "path": "embeddings", "k": 50}}},
            {"$project": {"_id": 1, "ndc": 1, "score": {"$meta": "searchScore"}}},
        ]))
        report["unfiltered_hits"] = len(unfiltered)
        report["unfiltered_distinct_ndcs"] = len({h["ndc"] for h in unfiltered})
        report["unfiltered_hits_for_target_ndc"] = sum(
            1 for h in unfiltered if h["ndc"] == target_ndc
        )

        try:
            filtered = list(db["baseline_occurrences"].aggregate([
                {"$search": {"cosmosSearch": {
                    "vector": vector,
                    "path": "embeddings",
                    "k": 50,
                    "filter": {"ndc": {"$eq": target_ndc}},
                }}},
                {"$project": {"_id": 1, "ndc": 1, "score": {"$meta": "searchScore"}}},
            ]))
        except Exception as exc:
            report["filter_error"] = f"{type(exc).__name__}: {exc}"
            print(json.dumps(report, indent=2))
            return 1

        report["filtered_hits"] = len(filtered)
        off_target = [h["ndc"] for h in filtered if h["ndc"] != target_ndc]
        report["filtered_off_target_hits"] = len(off_target)
        # A filter that is accepted but ignored returns foreign NDCs; that is the failure to catch.
        report["filtered_search_supported"] = bool(filtered) and not off_target

    print(json.dumps(report, indent=2))
    return 0 if report["filtered_search_supported"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
