# Starts a Container Apps Job and streams its console output until it terminates.
param(
    [Parameter(Mandatory = $true)][string]$Name,
    [Parameter(Mandatory = $true)][string]$ResourceGroup,
    [int]$PollSeconds = 20,
    [int]$MaxMinutes = 180
)

$ErrorActionPreference = "Stop"

$execution = az containerapp job start -g $ResourceGroup -n $Name --query name -o tsv
if ($LASTEXITCODE -ne 0) { throw "Failed to start job $Name" }
Write-Host "Execution: $execution"

$deadline = (Get-Date).AddMinutes($MaxMinutes)
$status = "Running"
while ((Get-Date) -lt $deadline) {
    Start-Sleep -Seconds $PollSeconds
    $status = az containerapp job execution show -g $ResourceGroup -n $Name `
        --job-execution-name $execution --query "properties.status" -o tsv 2>$null
    Write-Host "[$(Get-Date -Format HH:mm:ss)] $status"
    if ($status -in @("Succeeded", "Failed", "Cancelled")) { break }
}

Write-Host "--- logs ---"
az containerapp job logs show -g $ResourceGroup -n $Name `
    --execution $execution --container $Name --tail 200 2>$null

if ($status -ne "Succeeded") { throw "Job $Name finished with status $status" }
Write-Host "Job $Name succeeded."
