"""Verifies the generated baseline corpus: shape, duplication, and retrieval behaviour."""

from __future__ import annotations

import json
import os
import time

from sig_mvp.database import create_client
from sig_mvp.embed import DIMENSIONS
from sig_mvp.retrieval import Policy, retrieve_baseline

DB_NAME = "sigmvp"


def main() -> None:
    uri = os.environ.get("MONGO_URI")
    if not uri:
        raise SystemExit("MONGO_URI is not set")

    with create_client(uri) as client:
        db = client[DB_NAME]
        source = db["baseline_occurrences"]

        rows = source.count_documents({})
        distinct_sigs = len(source.distinct("doctors_sig"))
        distinct_ndcs = len(source.distinct("ndc"))

        report = {
            "rows": rows,
            "unique_sig_strings": distinct_sigs,
            "duplicate_rate": round(1 - distinct_sigs / rows, 4),
            "distinct_ndcs": distinct_ndcs,
            "vector_bytes_baseline": rows * DIMENSIONS * 8,
            "vector_bytes_if_deduplicated": distinct_sigs * DIMENSIONS * 8,
            "embeddings_computed": rows,
            "embeddings_needed_if_deduplicated": distinct_sigs,
        }

        probe = source.find_one({}, {"embeddings": 1, "ndc": 1, "doctors_sig": 1})
        policy = Policy()
        started = time.perf_counter()
        hits = retrieve_baseline(db, probe["embeddings"], probe["ndc"], policy)
        report["retrieval"] = {
            "policy": policy.name,
            "probe_ndc": probe["ndc"],
            "probe_sig": probe["doctors_sig"],
            "latency_ms": int((time.perf_counter() - started) * 1000),
            "examples_returned": len(hits),
            "all_hits_match_ndc": all(h["ndc"] == probe["ndc"] for h in hits),
            "top_scores": [round(h["score"], 6) for h in hits[:3]],
            "top_translated": [h.get("translated_sig") for h in hits[:2]],
        }

    print(json.dumps(report, indent=2, default=str))


if __name__ == "__main__":
    main()
