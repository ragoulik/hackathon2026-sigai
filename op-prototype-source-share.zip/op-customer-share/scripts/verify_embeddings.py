"""Verifies that loaded vectors match the pinned PubMedBERT contract."""

import math
import os

from sig_mvp.database import create_client

client = create_client(os.environ["MONGO_URI"])
db = client["sigmvp"]
baseline = db["baseline_occurrences"]
occurrences = db["ndc_sig_occurrences"]
vectors = db["sig_vectors"]

total = baseline.count_documents({})
with_vec = baseline.count_documents({"embeddings": {"$type": "array"}})
doc = baseline.find_one({})
vec = doc["embeddings"]

print(f"baseline occurrences        : {total}")
print(f"  with an embeddings array  : {with_vec}")
print(f"  vector length             : {len(vec)}")
print(f"  L2 norm                   : {math.sqrt(sum(x * x for x in vec)):.6f}")
print(f"  all numeric               : {all(isinstance(x, (int, float)) for x in vec)}")
print(f"  embedding_config_id       : {doc.get('embedding_config_id')}")

print(f"\nsig_vectors documents       : {vectors.count_documents({})}")
print(f"ndc_sig_occurrences         : {occurrences.count_documents({})}")
print(f"  carrying a vector         : {occurrences.count_documents({'embeddings': {'$type': 'array'}})}")

shared = vectors.find_one({}, {"embedding_input": 1, "ndcs": 1, "embedding_config_id": 1})
print(f"\nexample shared vector")
print(f"  sig text                  : {shared['embedding_input'][:60]}")
print(f"  distinct NDCs sharing it  : {len(shared['ndcs'])}")
print(f"  embedding_config_id       : {shared['embedding_config_id']}")

ids = vectors.distinct("embedding_config_id")
print(f"\ndistinct embedding_config_id across sig_vectors: {ids}")
client.close()
