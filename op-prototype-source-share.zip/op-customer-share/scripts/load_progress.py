"""Reports load progress for the generation job by counting rows in the target collection."""

from __future__ import annotations

import json
import os

from sig_mvp.database import create_client

DB_NAME = "sigmvp"


def main() -> None:
    uri = os.environ.get("MONGO_URI")
    if not uri:
        raise SystemExit("MONGO_URI is not set")
    with create_client(uri) as client:
        db = client[DB_NAME]
        report = {
            name: db[name].estimated_document_count()
            for name in ("baseline_occurrences", "sig_vectors", "ndc_sig_occurrences")
        }
        sample = db["baseline_occurrences"].find_one(
            {}, {"doctors_sig": 1, "ndc": 1, "embedding_config_id": 1, "embeddings": {"$slice": 3}}
        )
        report["sample"] = sample
    print(json.dumps(report, indent=2, default=str))


if __name__ == "__main__":
    main()
