"""Measures retrieval latency from inside Azure, where the API actually runs.

Latency measured from a workstation is dominated by internet round trips and is
not representative. This runs in-region so the numbers are usable.
"""

from __future__ import annotations

import argparse
import json
import os
import statistics
import time

from sig_mvp.database import create_client
from sig_mvp.reports import record_report
from sig_mvp.retrieval import DB_NAME, Policy, retrieve_baseline, retrieve_sig_centric


def percentile(values: list[float], fraction: float) -> float:
    if not values:
        return 0.0
    ordered = sorted(values)
    index = min(int(fraction * len(ordered)), len(ordered) - 1)
    return ordered[index]


def measure(db, layout: str, probes: list[dict], policy: Policy) -> dict:
    retrieve = retrieve_baseline if layout == "baseline" else retrieve_sig_centric
    latencies: list[float] = []
    counts: list[int] = []
    leaks = 0
    for probe in probes:
        started = time.perf_counter()
        hits = retrieve(db, probe["embeddings"], probe["ndc"], policy)
        latencies.append((time.perf_counter() - started) * 1000)
        counts.append(len(hits))
        leaks += sum(1 for h in hits if h["ndc"] != probe["ndc"])
    return {
        "layout": layout,
        "policy": policy.name,
        "probes": len(probes),
        "latency_ms_p50": round(statistics.median(latencies), 1),
        "latency_ms_p95": round(percentile(latencies, 0.95), 1),
        "latency_ms_min": round(min(latencies), 1),
        "latency_ms_max": round(max(latencies), 1),
        "examples_mean": round(statistics.mean(counts), 2),
        "empty_results": sum(1 for c in counts if c == 0),
        "ndc_leakage": leaks,
    }


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--probes", type=int, default=50)
    parser.add_argument("--policy", default="ndc_prefilter",
                        choices=["ndc_prefilter", "postfilter_reference"])
    args = parser.parse_args()

    uri = os.environ.get("MONGO_URI")
    if not uri:
        raise SystemExit("MONGO_URI is not set")

    with create_client(uri) as client:
        db = client[DB_NAME]
        probes = list(db["baseline_occurrences"].aggregate([
            {"$sample": {"size": args.probes}},
            {"$project": {"embeddings": 1, "ndc": 1}},
        ]))
        if not probes:
            raise SystemExit("baseline_occurrences is empty")

        report: dict = {
            "probe_count": len(probes),
            "baseline_rows": db["baseline_occurrences"].estimated_document_count(),
            "sig_vector_rows": db["sig_vectors"].estimated_document_count(),
            "results": [],
        }

        for policy_name in ("ndc_prefilter", "postfilter_reference"):
            policy = Policy(name=policy_name)
            report["results"].append(measure(db, "baseline", probes, policy))
            if report["sig_vector_rows"] > 0:
                report["results"].append(measure(db, "sig_centric", probes, policy))

        report["report_id"] = record_report(db, "bench", report)

    print(json.dumps(report, indent=2), flush=True)


if __name__ == "__main__":
    main()
