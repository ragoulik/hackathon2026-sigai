"""Retrieval adapters for both layouts, sharing one ranking policy.

ndc_prefilter matches the customer's current API, which constrains to the NDC
before the vector search. This was recorded as unknown in CurrentArchitecture.yaml
and established later by the customer; the diagram's left-to-right order suggests
the opposite. postfilter_reference keeps that drawn order available for comparison.

The two are not interchangeable on duplicated data: a global candidate cap is
consumed by copies of the nearest few SIG strings, so postfiltering can return
nothing for the requested NDC.
"""

from __future__ import annotations

from dataclasses import dataclass, asdict

DB_NAME = "sigmvp"
PREFILTER = "ndc_prefilter"


@dataclass(frozen=True)
class Policy:
    name: str = PREFILTER
    unique_candidate_limit: int = 50
    occurrence_candidate_limit: int = 200
    score_threshold: float = 0.0
    example_limit: int = 5

    def as_dict(self) -> dict:
        return asdict(self)


def _vector_stage(collection_rows: list[float], k: int, ndc: str | None) -> dict:
    search = {"vector": collection_rows, "path": "embeddings", "k": k}
    if ndc is not None:
        search["filter"] = {"ndc": {"$eq": ndc}}
    return {"$search": {"cosmosSearch": search}}


def _rank_key(item: dict) -> tuple[float, str]:
    return (-item["score"], str(item["_id"]))


def retrieve_baseline(db, query_vector, ndc: str, policy: Policy) -> list[dict]:
    prefilter = policy.name == PREFILTER
    pipeline = [
        _vector_stage(query_vector, policy.occurrence_candidate_limit, ndc if prefilter else None),
        {"$project": {
            "_id": 1, "ndc": 1, "doctors_sig": 1, "translated_sig": 1,
            "context": 1, "Rx_create_week": 1, "weighting_count": 1,
            "score": {"$meta": "searchScore"},
        }},
    ]
    candidates = list(db["baseline_occurrences"].aggregate(pipeline))
    candidates.sort(key=_rank_key)
    candidates = candidates[:policy.occurrence_candidate_limit]
    candidates = [c for c in candidates if c["score"] >= policy.score_threshold]
    if not prefilter:
        candidates = [c for c in candidates if c["ndc"] == ndc]
    return candidates[:policy.example_limit]


def retrieve_sig_centric(db, query_vector, ndc: str, policy: Policy) -> list[dict]:
    prefilter = policy.name == PREFILTER
    search = {"vector": query_vector, "path": "embeddings", "k": policy.unique_candidate_limit}
    if prefilter:
        search["filter"] = {"ndcs": {"$eq": ndc}}
    pipeline = [
        {"$search": {"cosmosSearch": search}},
        {"$project": {"_id": 1, "embedding_input": 1, "score": {"$meta": "searchScore"}}},
    ]
    hits = list(db["sig_vectors"].aggregate(pipeline))
    score_by_sig = {h["_id"]: h["score"] for h in hits}
    text_by_sig = {h["_id"]: h.get("embedding_input") for h in hits}
    if not score_by_sig:
        return []

    # Expansion covers every NDC first; narrowing here would change the ordering.
    occurrence_filter = {"sig_id": {"$in": list(score_by_sig)}}
    if prefilter:
        occurrence_filter["ndc"] = ndc
    expanded = []
    for occ in db["ndc_sig_occurrences"].find(occurrence_filter, {
        "_id": 1, "ndc": 1, "sig_id": 1, "translated_sig": 1,
        "context": 1, "Rx_create_week": 1, "weighting_count": 1,
    }):
        expanded.append({
            **occ,
            "doctors_sig": text_by_sig.get(occ["sig_id"]),
            "score": score_by_sig[occ["sig_id"]],
        })

    expanded.sort(key=_rank_key)
    expanded = expanded[:policy.occurrence_candidate_limit]
    expanded = [c for c in expanded if c["score"] >= policy.score_threshold]
    if not prefilter:
        expanded = [c for c in expanded if c["ndc"] == ndc]
    return expanded[:policy.example_limit]


def retrieve(db, layout: str, query_vector, ndc: str, policy: Policy) -> list[dict]:
    if layout == "baseline":
        return retrieve_baseline(db, query_vector, ndc, policy)
    if layout == "sig_centric":
        return retrieve_sig_centric(db, query_vector, ndc, policy)
    raise ValueError(f"unknown layout: {layout}")
