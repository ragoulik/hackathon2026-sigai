"""Load both storage layouts into Azure DocumentDB and create vector indexes.

baseline_occurrences  - one document per occurrence, vector duplicated inline
sig_vectors           - one document per unique exact SIG string
ndc_sig_occurrences   - one document per occurrence, referencing sig_vectors
"""

from __future__ import annotations

import argparse
import json
import os
from pathlib import Path

from sig_mvp.database import create_client

DB_NAME = "sigmvp"
BATCH = 500


def read_jsonl(path: Path) -> list[dict]:
    return [json.loads(line) for line in path.read_text(encoding="utf-8").splitlines()]


def insert_batched(collection, docs: list[dict]) -> int:
    for start in range(0, len(docs), BATCH):
        collection.insert_many(docs[start:start + BATCH], ordered=False)
    return collection.count_documents({})


def create_vector_index(db, collection: str, name: str, rows: int, kind: str) -> dict:
    options = {"kind": kind, "similarity": "COS", "dimensions": 768}
    if kind == "vector-ivf":
        options["numLists"] = max(1, rows // 1000)
    return db.command({
        "createIndexes": collection,
        "indexes": [{
            "name": name,
            "key": {"embeddings": "cosmosSearch"},
            "cosmosSearchOptions": options,
        }],
    })


def run(data_dir: Path, uri: str, drop: bool, kind: str) -> dict:
    occurrences = read_jsonl(data_dir / "occurrences.jsonl")
    vectors = read_jsonl(data_dir / "sig_vectors.jsonl")
    by_text = {v["embedding_input"]: v for v in vectors}

    missing = {o["doctors_sig"] for o in occurrences} - by_text.keys()
    if missing:
        raise SystemExit(f"{len(missing)} SIG strings have no vector; re-run sig_mvp.embed")

    baseline_docs = []
    occurrence_docs = []
    for occ in occurrences:
        vec = by_text[occ["doctors_sig"]]
        baseline_docs.append({
            **occ,
            "embeddings": vec["embeddings"],
            "embedding_config_id": vec["embedding_config_id"],
        })
        shared = {k: v for k, v in occ.items() if k != "doctors_sig"}
        occurrence_docs.append({**shared, "sig_id": vec["_id"]})

    client = create_client(uri)
    client.admin.command("ping")
    db = client[DB_NAME]

    if drop:
        for name in ("baseline_occurrences", "sig_vectors", "ndc_sig_occurrences"):
            db[name].drop()

    counts = {
        "baseline_occurrences": insert_batched(db["baseline_occurrences"], baseline_docs),
        "sig_vectors": insert_batched(db["sig_vectors"], vectors),
        "ndc_sig_occurrences": insert_batched(db["ndc_sig_occurrences"], occurrence_docs),
    }

    db["ndc_sig_occurrences"].create_index([("sig_id", 1), ("ndc", 1)])
    db["ndc_sig_occurrences"].create_index([("ndc", 1), ("sig_id", 1)])
    db["baseline_occurrences"].create_index([("ndc", 1)])

    indexes = {
        "sig_vectors": create_vector_index(db, "sig_vectors", "sig_vectors_vec", len(vectors), kind),
        "baseline_occurrences": create_vector_index(
            db, "baseline_occurrences", "baseline_vec", len(baseline_docs), kind
        ),
    }

    report = {
        "database": DB_NAME,
        "counts": counts,
        "expected_occurrences": len(occurrences),
        "expected_vectors": len(vectors),
        "layout_counts_match": counts["baseline_occurrences"] == counts["ndc_sig_occurrences"]
        == len(occurrences) and counts["sig_vectors"] == len(vectors),
        "vector_index_kind": kind,
        "vector_index_ok": all(r.get("ok") == 1 for r in indexes.values()),
    }
    client.close()
    return report


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--data", type=Path, default=Path("data"))
    parser.add_argument("--drop", action="store_true")
    parser.add_argument("--kind", default="vector-ivf",
                        choices=["vector-ivf", "vector-hnsw", "vector-diskann"])
    args = parser.parse_args()

    uri = os.environ.get("MONGO_URI")
    if not uri:
        raise SystemExit("MONGO_URI is not set")
    report = run(args.data, uri, args.drop, args.kind)
    print(json.dumps(report, indent=2))
    if not report["layout_counts_match"] or not report["vector_index_ok"]:
        raise SystemExit("Loaded counts or vector indexes did not match expectations")


if __name__ == "__main__":
    main()
