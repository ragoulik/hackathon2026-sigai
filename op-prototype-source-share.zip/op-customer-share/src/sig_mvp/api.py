"""MVP SIG translation API.

Per-item flow: validate -> embed doctors_sig -> vector search -> assemble prompt
from retrieved history -> Azure OpenAI structured generation -> response.
Generation failures surface as needs_review, never as an invented translation.
"""

from __future__ import annotations

import os
import time
from pathlib import Path
from typing import Any

from fastapi import Depends, FastAPI, HTTPException, Query
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel, Field
from pymongo import MongoClient

from sig_mvp import cache, demo_store
from sig_mvp.auth import caller_label, require_token
from sig_mvp.database import create_client
from sig_mvp.generation import generate, generate_ungrounded
from sig_mvp.retrieval import DB_NAME, Policy, retrieve

MAX_BATCH = 20

app = FastAPI(title="SIG MVP translation API", version="0.2.0")
_client: MongoClient | None = None
_embedder: Any = None
_embedder_error: str | None = None


class SigRequestItem(BaseModel):
    rx_number: str | None = None
    drug_form: str | None = None
    drug_route_of_admin: str | None = None
    drug_name: str | None = None
    ndc: str = Field(min_length=1)
    strength: str | None = None
    units: str | None = None
    doctors_sig: str = Field(min_length=1)
    erx_notes: str | None = None
    rx_quantity: str | None = None
    upd_unit: str | None = None
    PK_SZ: str | None = None
    pk_sz_unit: str | None = None


class SigResponseItem(BaseModel):
    rx_number: str | None = None
    drug_form: str | None = None
    drug_route_of_admin: str | None = None
    drug_name: str | None = None
    ndc: str
    strength: str | None = None
    units: str | None = None
    doctors_sig: str
    erx_notes: str | None = None
    translated_sig: str | None = None
    upd: str | None = None
    cycle_days: str | None = None
    needs_review: bool = True
    reason: str
    examples: list[dict] = []
    demo: dict = Field(default_factory=dict, alias="_demo")

    model_config = {"populate_by_name": True}


def _db():
    global _client
    uri = os.environ.get("MONGO_URI")
    if not uri:
        raise HTTPException(status_code=503, detail="MONGO_URI not configured")
    if _client is None:
        _client = create_client(uri, server_selection_timeout_ms=15000)
        try:
            cache.ensure_index(_client[DB_NAME])
        except Exception:  # noqa: BLE001 - expiry is enforced on read regardless
            pass
    return _client[DB_NAME]


def _load_embedder():
    """Optional. The slim container ships without torch; local runs have it."""
    global _embedder, _embedder_error
    if _embedder is not None or _embedder_error is not None:
        return _embedder
    try:
        from sig_mvp.embed import PubMedBertBackend

        _embedder = PubMedBertBackend()
    except Exception as exc:  # noqa: BLE001 - reported, never silently swallowed
        _embedder_error = f"{type(exc).__name__}: {exc}"
    return _embedder


def _query_vector(db, text: str) -> tuple[list[float] | None, str]:
    """Always embed the incoming SIG.

    Reusing a stored vector when the text happens to match history would skip the
    embedding stage for sig_centric only, making it look faster than baseline for
    a reason unrelated to storage layout.
    """
    embedder = _load_embedder()
    if embedder is None:
        return None, f"no_embedding_backend ({_embedder_error})"
    return embedder.encode(text), "computed_vector"


def _require_layout_ready(db, layout: str) -> None:
    if layout == "sig_centric" and db["sig_vectors"].estimated_document_count() == 0:
        raise HTTPException(
            status_code=409,
            detail="sig_centric layout is not populated; run sig_mvp.migrate first",
        )


@app.get("/healthz")
def healthz() -> dict:
    return {"status": "ok"}


@app.get("/readyz")
def readyz() -> dict:
    try:
        _db().command("ping")
    except Exception as exc:  # noqa: BLE001
        raise HTTPException(status_code=503, detail=type(exc).__name__) from exc
    return {"status": "ready"}


@app.post("/v1/sig/translate", response_model=list[SigResponseItem])
def translate(
    items: list[SigRequestItem],
    layout: str = Query("baseline", pattern="^(baseline|sig_centric)$"),
    policy_name: str = Query("ndc_prefilter",
                             pattern="^(ndc_prefilter|postfilter_reference)$"),
    example_limit: int = Query(5, ge=1, le=20),
    generate_translation: bool = Query(True),
    allow_ungrounded: bool = Query(True),
    use_cache: bool = Query(True),
    cache_ttl_seconds: int = Query(cache.DEFAULT_TTL_SECONDS, ge=0, le=86400),
    claims: dict = Depends(require_token),
) -> list[SigResponseItem]:
    if not items:
        raise HTTPException(status_code=422, detail="empty batch")
    if len(items) > MAX_BATCH:
        raise HTTPException(status_code=422, detail=f"batch exceeds {MAX_BATCH} items")

    db = _db()
    _require_layout_ready(db, layout)
    policy = Policy(name=policy_name, example_limit=example_limit)

    results = []
    for item in items:
        key = cache.cache_key(item.ndc, item.doctors_sig, layout, policy.name, example_limit)
        cached = cache.get(db, key, ttl_seconds=cache_ttl_seconds) if use_cache else None
        if cached:
            results.append(SigResponseItem(**cached["item"]))
            continue

        vector, source = _query_vector(db, item.doctors_sig)
        translated, needs_review, usage, error = None, True, {}, None
        grounded = False

        if vector is None:
            examples, reason = [], source
        else:
            examples = retrieve(db, layout, vector, item.ndc, policy)
            grounded = bool(examples)
            if not generate_translation:
                reason = "retrieval_only_generation_disabled"
            elif not examples and not allow_ungrounded:
                reason = "no_matching_history"
            else:
                result = (generate(item.model_dump(), examples) if examples
                          else generate_ungrounded(item.model_dump()))
                translated = result.translated_sig
                needs_review = result.needs_review
                reason = result.reason if (examples or translated) else "no_matching_history"
                usage = result.usage
                error = result.error

        response_item = SigResponseItem(
            **item.model_dump(exclude={"rx_quantity", "upd_unit", "PK_SZ", "pk_sz_unit"}),
            translated_sig=translated,
            # Not inferred from strength or package size; history does not supply them.
            upd=None,
            cycle_days=None,
            needs_review=needs_review,
            reason=reason,
            examples=[{**e, "_id": str(e["_id"]), "vector_source": source} for e in examples],
            _demo={
                "layout": layout,
                "policy": policy.name,
                "vector_source": source,
                "example_count": len(examples),
                "grounded_in_history": grounded,
                "generation_error": error,
                "token_usage": usage,
                "cache_hit": False,
            },
        )
        # Errors are not cached; a transient failure must not be replayed for an hour.
        if use_cache and translated is not None and reason != "generation_error":
            cache.put(db, key, {"item": response_item.model_dump(by_alias=True)},
                      ttl_seconds=cache_ttl_seconds)
        results.append(response_item)
    return results


@app.get("/v1/ndcs")
def list_ndcs(q: str | None = None, limit: int = Query(20, ge=1, le=100),
              claims: dict = Depends(require_token)) -> list[dict]:
    return demo_store.search_ndcs(_db(), q, limit)


@app.get("/v1/ndcs/random")
def pick_random_ndc(claims: dict = Depends(require_token)) -> dict:
    db = _db()
    choice = demo_store.random_ndc(db)
    if not choice:
        raise HTTPException(status_code=404, detail="no NDCs loaded")
    choice["sample_sigs"] = demo_store.sample_sigs(db, choice["ndc"])
    return choice


@app.get("/v1/runs")
def run_history(limit: int = Query(50, ge=1, le=200),
                claims: dict = Depends(require_token)) -> list[dict]:
    return demo_store.list_runs(_db(), limit)


@app.get("/v1/runs/{run_id}")
def run_detail(run_id: str, claims: dict = Depends(require_token)) -> dict:
    row = demo_store.get_run(_db(), run_id)
    if not row:
        raise HTTPException(status_code=404, detail="run not found")
    return row


@app.get("/v1/me")
def whoami(claims: dict = Depends(require_token)) -> dict:
    return {"caller": caller_label(claims), "client_id": claims.get("azp") or claims.get("appid")}


@app.post("/v1/demo/run")
def demo_run(
    item: SigRequestItem,
    layout: str = Query("baseline", pattern="^(baseline|sig_centric)$"),
    policy_name: str = Query("ndc_prefilter",
                             pattern="^(ndc_prefilter|postfilter_reference)$"),
    example_limit: int = Query(5, ge=1, le=20),
    use_cache: bool = Query(True),
    cache_ttl_seconds: int = Query(cache.DEFAULT_TTL_SECONDS, ge=0, le=86400),
    claims: dict = Depends(require_token),
) -> dict:
    """Single traced request: captures each stage's input and output for the UI."""
    db = _db()
    _require_layout_ready(db, layout)
    policy = Policy(name=policy_name, example_limit=example_limit)
    started = time.perf_counter()

    key = cache.cache_key(item.ndc, item.doctors_sig, layout, policy.name, example_limit)
    cached = cache.get(db, key, ttl_seconds=cache_ttl_seconds) if use_cache else None
    if cached:
        hit = dict(cached["response"])
        hit["cache"] = {"hit": True, "age_seconds": cached["age_seconds"],
                        "ttl_seconds": cache_ttl_seconds}
        hit["total_ms"] = int((time.perf_counter() - started) * 1000)
        hit["trace"] = [{
            "id": "cache",
            "title": "Translation cache hit",
            "input": {"ndc": item.ndc, "doctors_sig": item.doctors_sig,
                      "layout": layout, "policy": policy.name, "cache_key": key},
            "output": {"age_seconds": cached["age_seconds"],
                       "translated_sig": hit.get("translated_sig"),
                       "stages_skipped": ["embedding", "vector_search", "generation"]},
            "latency_ms": hit["total_ms"],
        }] + cached["response"].get("trace", [])
        hit["caller"] = caller_label(claims)
        hit["id"] = demo_store.save_run(db, hit)
        return hit

    t0 = time.perf_counter()
    vector, source = _query_vector(db, item.doctors_sig)
    embed_ms = int((time.perf_counter() - t0) * 1000)

    stages: list[dict] = [{
        "id": "embedding",
        "title": "Embed SIG (PubMedBERT)",
        "input": {"doctors_sig": item.doctors_sig},
        "output": {
            "vector_source": source,
            "dimensions": len(vector) if vector else 0,
            "preview": [round(v, 6) for v in vector[:8]] if vector else [],
        },
        "latency_ms": embed_ms,
    }]

    examples: list[dict] = []
    result = None
    if vector is None:
        reason, translated, needs_review = source, None, True
    else:
        t1 = time.perf_counter()
        examples = retrieve(db, layout, vector, item.ndc, policy)
        search_ms = int((time.perf_counter() - t1) * 1000)
        stages.append({
            "id": "vector_search",
            "title": f"Vector search ({layout})",
            "input": {
                "collection": "sig_vectors" if layout == "sig_centric" else "baseline_occurrences",
                "operator": "$search.cosmosSearch",
                "ndc_filter": item.ndc,
                "policy": policy.name,
                # k counts unique SIG texts in sig_centric but duplicated occurrence rows in baseline.
                "k": policy.unique_candidate_limit if layout == "sig_centric"
                else policy.occurrence_candidate_limit,
                "collection_size": db[
                    "sig_vectors" if layout == "sig_centric" else "baseline_occurrences"
                ].estimated_document_count(),
            },
            "output": {
                "example_count": len(examples),
                "examples": [
                    {
                        "occurrence_id": str(e["_id"]),
                        "ndc": e["ndc"],
                        "score": e["score"],
                        "doctors_sig": e.get("doctors_sig"),
                        "translated_sig": e.get("translated_sig"),
                    }
                    for e in examples
                ],
            },
            "latency_ms": search_ms,
        })

        if not examples:
            # Unverified rewrite from the SIG text alone; always routed to review.
            result = generate_ungrounded(item.model_dump())
            translated = result.translated_sig
            needs_review = True
            reason = result.reason if translated else "no_matching_history"
        else:
            result = generate(item.model_dump(), examples)
            translated = result.translated_sig
            needs_review = result.needs_review
            reason = result.reason

        stages.append({
            "id": "generation",
            "title": "Azure OpenAI (gpt-4o, structured output)"
            + ("" if examples else " - no history, unverified"),
            "input": {
                "deployment": os.environ.get("AZURE_OPENAI_DEPLOYMENT", "sig-gpt4o"),
                "grounded_in_history": bool(examples),
                "system_prompt": result.system_prompt,
                "user_prompt": result.user_prompt,
            },
            "output": {
                "raw_response": result.raw_response,
                "token_usage": result.usage,
                "error": result.error,
            },
            "latency_ms": result.latency_ms,
        })

    total_ms = int((time.perf_counter() - started) * 1000)
    response = {
        "request": item.model_dump(),
        "layout": layout,
        "policy": policy.name,
        "translated_sig": translated,
        "needs_review": needs_review,
        "reason": reason,
        "grounded_in_history": bool(examples),
        "total_ms": total_ms,
        "cache": {"hit": False, "ttl_seconds": cache_ttl_seconds},
        "caller": caller_label(claims),
        "trace": stages,
    }
    # Errors are not cached; a transient failure must not be replayed for an hour.
    if use_cache and translated is not None and reason != "generation_error":
        cache.put(db, key, {"response": response}, ttl_seconds=cache_ttl_seconds)
    response["id"] = demo_store.save_run(db, response)
    return response


# Mounted last so every API route is matched first; StaticFiles would otherwise
# answer POSTs with 405.
_STATIC_DIR = Path(os.environ.get("UI_DIST", "/app/ui"))
if _STATIC_DIR.is_dir():
    app.mount("/", StaticFiles(directory=_STATIC_DIR, html=True), name="ui")
