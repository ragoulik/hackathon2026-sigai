"""Deterministic synthetic SIG corpus shaped like the customer's production data.

Nonclinical test data only. Dose, frequency and duration are never inferred from
drug metadata; they stay conspicuous placeholders.

The customer reports roughly 70% of occurrence rows are exact-string duplicates,
so duplication is a parameter here rather than an accident of template count.
Deduplication savings are a direct function of this distribution.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import random
import unicodedata
from collections import Counter, defaultdict
from pathlib import Path

import requests

DATASET_ID = "corpus_v2"
TEMPLATE_VERSION = "v2"
OPENFDA_URL = "https://api.fda.gov/drug/ndc.json"

DOSE = "[SYNTHETIC DOSE]"
FREQ = "[SYNTHETIC FREQUENCY]"
DURATION = "[SYNTHETIC DURATION]"

# (route_bucket, provider phrasing, normalized pharmacy phrasing)
BASE_FORMS: list[tuple[str, str, str]] = [
    ("oral", f"take {DOSE} tablet by oral route", f"TAKE {DOSE} TABLET BY MOUTH"),
    ("oral", f"take {DOSE} tablet by mouth", f"TAKE {DOSE} TABLET BY MOUTH"),
    ("oral", f"take {DOSE} tablet orally", f"TAKE {DOSE} TABLET BY MOUTH"),
    ("oral", f"take {DOSE} capsule by oral route", f"TAKE {DOSE} CAPSULE BY MOUTH"),
    ("oral", f"take {DOSE} capsule by mouth", f"TAKE {DOSE} CAPSULE BY MOUTH"),
    ("oral", f"swallow {DOSE} capsule whole", f"SWALLOW {DOSE} CAPSULE WHOLE"),
    ("oral", "take one half tablet by oral route", "TAKE 1/2 TABLET BY MOUTH"),
    ("oral", f"take {DOSE} ml by oral route", f"TAKE {DOSE} ML BY MOUTH"),
    ("oral", f"take {DOSE} ml of oral solution", f"TAKE {DOSE} ML BY MOUTH"),
    ("oral", f"take {DOSE} teaspoonful by mouth", f"TAKE {DOSE} TSP BY MOUTH"),
    ("oral", f"chew {DOSE} tablet", f"CHEW {DOSE} TABLET"),
    ("oral", f"dissolve {DOSE} tablet in water and drink", f"DISSOLVE {DOSE} TABLET IN WATER AND DRINK"),
    ("oral", f"rinse with {DOSE} ml and spit", f"RINSE WITH {DOSE} ML AND SPIT OUT"),
    ("oral", f"take {DOSE} packet mixed in water", f"TAKE {DOSE} PACKET MIXED IN WATER"),
    ("sublingual", f"place {DOSE} tablet under the tongue", f"PLACE {DOSE} TABLET UNDER THE TONGUE"),
    ("sublingual", f"dissolve {DOSE} tablet under the tongue", f"DISSOLVE {DOSE} TABLET UNDER THE TONGUE"),
    ("topical", f"apply {DOSE} topically to affected area", f"APPLY {DOSE} TO AFFECTED AREA"),
    ("topical", f"apply {DOSE} thin layer to the affected area", f"APPLY {DOSE} THIN LAYER TO AFFECTED AREA"),
    ("topical", f"rub {DOSE} into the affected area", f"RUB {DOSE} INTO AFFECTED AREA"),
    ("topical", f"apply {DOSE} patch to skin", f"APPLY {DOSE} PATCH TO THE SKIN"),
    ("topical", f"apply {DOSE} to the scalp", f"APPLY {DOSE} TO THE SCALP"),
    ("injection", f"inject {DOSE} subcutaneously", f"INJECT {DOSE} UNDER THE SKIN"),
    ("injection", f"inject {DOSE} under the skin", f"INJECT {DOSE} UNDER THE SKIN"),
    ("injection", f"inject {DOSE} intramuscularly", f"INJECT {DOSE} INTO THE MUSCLE"),
    ("ophthalmic", f"instill {DOSE} drop into each eye", f"PLACE {DOSE} DROP IN EACH EYE"),
    ("ophthalmic", f"instill {DOSE} drop into the affected eye", f"PLACE {DOSE} DROP IN AFFECTED EYE"),
    ("otic", f"instill {DOSE} drop into each ear", f"PLACE {DOSE} DROP IN EACH EAR"),
    ("otic", f"instill {DOSE} drop into the affected ear", f"PLACE {DOSE} DROP IN AFFECTED EAR"),
    ("respiratory", f"inhale {DOSE} puff by inhalation", f"INHALE {DOSE} PUFF"),
    ("respiratory", f"inhale {DOSE} puff into the lungs", f"INHALE {DOSE} PUFF"),
    ("respiratory", f"use {DOSE} nebulizer treatment", f"USE {DOSE} NEBULIZER TREATMENT"),
    ("nasal", f"use {DOSE} spray in each nostril", f"SPRAY {DOSE} IN EACH NOSTRIL"),
    ("nasal", f"spray {DOSE} into each nostril", f"SPRAY {DOSE} IN EACH NOSTRIL"),
    ("rectal", f"insert {DOSE} suppository rectally", f"INSERT {DOSE} SUPPOSITORY RECTALLY"),
    ("vaginal", f"insert {DOSE} applicator vaginally", f"INSERT {DOSE} APPLICATOR VAGINALLY"),
]

TIMING = [
    ("", ""),
    (" in the morning", " IN THE MORNING"),
    (" at bedtime", " AT BEDTIME"),
    (" in the evening", " IN THE EVENING"),
    (" at noon", " AT NOON"),
    (" every morning and evening", " EVERY MORNING AND EVENING"),
    (" before breakfast", " BEFORE BREAKFAST"),
    (" after dinner", " AFTER DINNER"),
    (" at the same time each day", " AT THE SAME TIME EACH DAY"),
    (" every other day", " EVERY OTHER DAY"),
    (" on weekdays only", " ON WEEKDAYS ONLY"),
]

FOOD = [
    ("", ""),
    (" with food", " WITH FOOD"),
    (" with meals", " WITH MEALS"),
    (" with a full glass of water", " WITH A FULL GLASS OF WATER"),
    (" without regard to meals", " WITHOUT REGARD TO MEALS"),
    (" on an empty stomach", " ON AN EMPTY STOMACH"),
]

DURATION_MODS = [
    ("", ""),
    (f" for {DURATION}", f" FOR {DURATION}"),
    (f" for {DURATION} then stop", f" FOR {DURATION} THEN STOP"),
    (" until finished", " UNTIL FINISHED"),
    (f" for {DURATION} or as directed", f" FOR {DURATION} OR AS DIRECTED"),
]

PRN = [
    ("", ""),
    (" as needed", " AS NEEDED"),
    (" as needed for pain", " AS NEEDED FOR PAIN"),
    (" as directed", " AS DIRECTED"),
]

# Shorthand a prescriber might type. Meaning is unchanged, so the normalized
# output stays identical and only the stored string differs.
ABBREVIATIONS = [
    ("by oral route", "po"),
    ("by mouth", "po"),
    ("tablet", "tab"),
    ("capsule", "cap"),
    ("as needed", "prn"),
    ("at bedtime", "qhs"),
    ("in the morning", "qam"),
    ("subcutaneously", "subq"),
    ("intramuscularly", "im"),
    ("into each eye", "ou"),
    ("suppository", "supp"),
    ("teaspoonful", "tsp"),
]

ROUTE_KEYWORDS = {
    "sublingual": "sublingual",
    "buccal": "sublingual",
    "transdermal": "topical",
    "cutaneous": "topical",
    "topical": "topical",
    "intravenous": "injection",
    "intramuscular": "injection",
    "subcutaneous": "injection",
    "ophthalmic": "ophthalmic",
    "auricular": "otic",
    "otic": "otic",
    "inhalation": "respiratory",
    "respiratory": "respiratory",
    "nasal": "nasal",
    "rectal": "rectal",
    "vaginal": "vaginal",
    "oral": "oral",
}


def sig_key(text: str) -> str:
    """Exact-string dedup key. NFC normalization stops identical text splitting groups."""
    return hashlib.sha256(unicodedata.normalize("NFC", text).encode("utf-8")).hexdigest()


def normalize_ndc11(package_ndc: str) -> str | None:
    """Pad a documented 10-digit segmentation to 5-4-2. Ambiguous input is rejected."""
    parts = package_ndc.strip().split("-")
    if len(parts) != 3 or not all(p.isdigit() for p in parts):
        return None
    a, b, c = parts
    lengths = (len(a), len(b), len(c))
    if lengths == (5, 4, 2):
        pass
    elif lengths == (4, 4, 2):
        a = a.zfill(5)
    elif lengths == (5, 3, 2):
        b = b.zfill(4)
    elif lengths == (5, 4, 1):
        c = c.zfill(2)
    else:
        return None
    return a + b + c


def route_bucket(route: str, dosage_form: str) -> str:
    haystack = f"{route} {dosage_form}".lower()
    for keyword, bucket in ROUTE_KEYWORDS.items():
        if keyword in haystack:
            return bucket
    return "oral"


def fetch_openfda(min_ndcs: int, timeout: float) -> tuple[list[dict], str | None]:
    """Return package-level records from openFDA, or an error string on failure."""
    records: dict[str, dict] = {}
    skip = 0
    try:
        while len(records) < min_ndcs and skip < 25000:
            resp = requests.get(OPENFDA_URL, params={"limit": 1000, "skip": skip}, timeout=timeout)
            if resp.status_code == 429:
                return list(records.values()), "openfda_rate_limited"
            resp.raise_for_status()
            results = resp.json().get("results", [])
            if not results:
                break
            for item in results:
                for pkg in item.get("packaging", []) or []:
                    raw = pkg.get("package_ndc")
                    if not raw:
                        continue
                    norm = normalize_ndc11(raw)
                    if norm is None or norm in records:
                        continue
                    routes = item.get("route") or []
                    form = item.get("dosage_form") or ""
                    records[norm] = {
                        "ndc": norm,
                        "ndc_original": raw,
                        "drug_name": item.get("brand_name") or item.get("generic_name") or "",
                        "drug_form": form,
                        "route": routes[0] if routes else "",
                        "route_bucket": route_bucket(routes[0] if routes else "", form),
                        "source": "openfda",
                    }
            skip += 1000
    except requests.RequestException as exc:
        return list(records.values()), f"openfda_request_failed: {type(exc).__name__}"
    return list(records.values()), None


def synthetic_ndcs(count: int, rng: random.Random) -> list[dict]:
    """Clearly fake identifiers, used only when the public source falls short."""
    buckets = sorted({b for b, _, _ in BASE_FORMS})
    out = []
    for i in range(count):
        labeler = 99000 + (i // 100)
        norm = f"{labeler:05d}{(i % 100) + 1:04d}01"
        out.append({
            "ndc": norm,
            "ndc_original": f"{labeler:05d}-{(i % 100) + 1:04d}-01",
            "drug_name": f"[SYNTHETIC DRUG {i:05d}]",
            "drug_form": "[SYNTHETIC FORM]",
            "route": "[SYNTHETIC ROUTE]",
            "route_bucket": buckets[i % len(buckets)],
            "source": "synthetic",
        })
    return out


def _apply_noise(text: str, variant: int, rng: random.Random) -> str:
    """Prescriber typing noise: changes the stored string, not the meaning."""
    if variant == 0:
        return text
    if variant == 1:
        return text.upper()
    if variant == 2:
        return text + "."
    if variant == 3:
        return text.replace(" ", "  ", 1)
    if variant == 4:
        for long_form, short in ABBREVIATIONS:
            if long_form in text:
                return text.replace(long_form, short, 1)
        return text + " prn"
    if variant == 5:
        return text.capitalize()
    if variant == 6:
        words = [w for w in text.split(" ") if len(w) > 4 and w.isalpha()]
        if not words:
            return text + " as directed"
        target = rng.choice(words)
        i = rng.randrange(len(target) - 1)
        return text.replace(target, target[:i] + target[i + 1] + target[i] + target[i + 2:], 1)
    words = [w for w in text.split(" ") if len(w) > 5 and w.isalpha()]
    if not words:
        return text.rstrip(".") + " ,"
    target = rng.choice(words)
    i = rng.randrange(1, len(target))
    return text.replace(target, target[:i] + target[i + 1:], 1)


def build_vocabulary(unique_target: int, seed: int) -> list[dict]:
    """Generate exactly unique_target distinct provider strings, tagged by route."""
    rng = random.Random(seed ^ 0x5163)
    combos = [
        (bi, ti, fi, di, pi)
        for bi in range(len(BASE_FORMS))
        for ti in range(len(TIMING))
        for fi in range(len(FOOD))
        for di in range(len(DURATION_MODS))
        for pi in range(len(PRN))
    ]
    rng.shuffle(combos)

    vocabulary: list[dict] = []
    seen: set[str] = set()
    variant = 0
    while len(vocabulary) < unique_target:
        added_this_pass = False
        for bi, ti, fi, di, pi in combos:
            if len(vocabulary) >= unique_target:
                break
            bucket, provider, translated = BASE_FORMS[bi]
            canonical = (
                f"{provider} {FREQ}{TIMING[ti][0]}{FOOD[fi][0]}"
                f"{DURATION_MODS[di][0]}{PRN[pi][0]}"
            )
            text = _apply_noise(canonical, variant, rng)
            if text in seen:
                continue
            seen.add(text)
            added_this_pass = True
            vocabulary.append({
                "text": text,
                "translated": (
                    f"{translated} {FREQ}{TIMING[ti][1]}{FOOD[fi][1]}"
                    f"{DURATION_MODS[di][1]}{PRN[pi][1]}"
                ),
                "route_bucket": bucket,
            })
        variant += 1
        if not added_this_pass and variant > 40:
            raise SystemExit(
                f"vocabulary exhausted at {len(vocabulary)} of {unique_target}; "
                "raise --unique-ratio or lower --occurrences"
            )
    return vocabulary


def allocate_frequencies(unique_count: int, total: int, zipf_exponent: float,
                         seed: int) -> list[int]:
    """Give every string one row, then spread the remainder by a Zipf law.

    Realized unique count and total are exact, so the reported duplicate rate is
    the configured one rather than an approximation.
    """
    if total < unique_count:
        raise SystemExit("occurrences must be >= unique string count")
    remainder = total - unique_count
    weights = [1.0 / ((i + 1) ** zipf_exponent) for i in range(unique_count)]
    weight_sum = sum(weights)

    raw = [remainder * w / weight_sum for w in weights]
    counts = [int(x) for x in raw]
    shortfall = remainder - sum(counts)
    # Largest-remainder apportionment keeps the total exact without a random walk.
    order = sorted(range(unique_count), key=lambda i: (-(raw[i] - counts[i]), i))
    for i in order[:shortfall]:
        counts[i] += 1

    frequencies = [c + 1 for c in counts]
    random.Random(seed ^ 0x7A19).shuffle(frequencies)
    return frequencies


def build(out_dir: Path, ndc_count: int, occurrences_target: int, unique_ratio: float,
          zipf_exponent: float, seed: int, timeout: float) -> dict:
    rng = random.Random(seed)
    drugs, source_error = fetch_openfda(ndc_count, timeout)
    real_count = len(drugs)
    if real_count < ndc_count:
        drugs = drugs + synthetic_ndcs(ndc_count - real_count, rng)
    drugs = sorted(drugs, key=lambda d: d["ndc"])[:ndc_count]

    by_bucket: dict[str, list[dict]] = defaultdict(list)
    for drug in drugs:
        by_bucket[drug["route_bucket"]].append(drug)
    oral_fallback = by_bucket.get("oral") or drugs

    unique_target = max(1, round(occurrences_target * unique_ratio))
    vocabulary = build_vocabulary(unique_target, seed)
    frequencies = allocate_frequencies(unique_target, occurrences_target, zipf_exponent, seed)

    out_dir.mkdir(parents=True, exist_ok=True)
    occ_path = out_dir / "occurrences.jsonl"

    sig_counts: Counter[str] = Counter()
    ndcs_per_sig: dict[str, set[str]] = defaultdict(set)
    sigs_per_ndc: dict[str, set[str]] = defaultdict(set)
    occ_per_ndc: Counter[str] = Counter()
    counter = 0

    with occ_path.open("w", encoding="utf-8") as fh:
        for entry, freq in zip(vocabulary, frequencies):
            # Route-compatible assignment avoids nonsense pairings such as an injected tablet.
            pool = by_bucket.get(entry["route_bucket"]) or oral_fallback
            for _ in range(freq):
                counter += 1
                drug = pool[rng.randrange(len(pool))]
                occ_id = f"occ_{counter:08d}"
                fh.write(json.dumps({
                    "_id": occ_id,
                    "dataset_id": DATASET_ID,
                    "ndc": drug["ndc"],
                    "ndc_original": drug["ndc_original"],
                    "doctors_sig": entry["text"],
                    "translated_sig": entry["translated"],
                    "UNITS_PER_DAY": None,
                    "Rx_create_week": f"2026-W{rng.randint(1, 52):02d}",
                    "weighting_count": 1,
                    "context": {
                        "drug_name": drug["drug_name"],
                        "drug_form": drug["drug_form"],
                        "route": drug["route"],
                        "ndc_source": drug["source"],
                    },
                    "provenance": {
                        "source_occurrence_id": occ_id,
                        "template_version": TEMPLATE_VERSION,
                        "route_bucket": entry["route_bucket"],
                        "seed": seed,
                    },
                    "synthetic": True,
                    "clinical_use": False,
                }, ensure_ascii=False) + "\n")
                sig_counts[entry["text"]] += 1
                ndcs_per_sig[entry["text"]].add(drug["ndc"])
                sigs_per_ndc[drug["ndc"]].add(entry["text"])
                occ_per_ndc[drug["ndc"]] += 1

    freqs = sorted(sig_counts.values(), reverse=True)
    per_ndc_occ = sorted(occ_per_ndc.values())
    per_ndc_sigs = sorted(len(v) for v in sigs_per_ndc.values())

    manifest = {
        "dataset_id": DATASET_ID,
        "seed": seed,
        "template_version": TEMPLATE_VERSION,
        "corpus_sha256": hashlib.sha256(occ_path.read_bytes()).hexdigest(),
        "ndc_count": len(drugs),
        "real_public_ndc_count": sum(1 for d in drugs if d["source"] == "openfda"),
        "synthetic_ndc_count": sum(1 for d in drugs if d["source"] == "synthetic"),
        "public_source_error": source_error,
        "occurrence_count": counter,
        "unique_sig_count": len(sig_counts),
        "duplicate_rate": round(1 - len(sig_counts) / counter, 4),
        "target_duplicate_rate": round(1 - unique_ratio, 4),
        "zipf_exponent": zipf_exponent,
        "top_sig_frequency": freqs[0],
        "median_sig_frequency": freqs[len(freqs) // 2],
        "singleton_sig_count": sum(1 for f in freqs if f == 1),
        "sigs_shared_across_multiple_ndcs": sum(1 for v in ndcs_per_sig.values() if len(v) > 1),
        "ndcs_with_occurrences": len(occ_per_ndc),
        "occurrences_per_ndc_min": per_ndc_occ[0],
        "occurrences_per_ndc_median": per_ndc_occ[len(per_ndc_occ) // 2],
        "occurrences_per_ndc_max": per_ndc_occ[-1],
        "distinct_sigs_per_ndc_median": per_ndc_sigs[len(per_ndc_sigs) // 2],
        "dedup_key": "exact_string_sha256",
        "clinical_use": False,
        "embedding_backend": None,
    }
    (out_dir / "manifest.json").write_text(json.dumps(manifest, indent=2) + "\n", encoding="utf-8")
    return manifest


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--out", type=Path, default=Path("data"))
    parser.add_argument("--ndcs", type=int, default=2000)
    parser.add_argument("--occurrences", type=int, default=100000)
    parser.add_argument("--unique-ratio", type=float, default=0.30,
                        help="share of rows holding a distinct SIG; 0.30 means 70%% duplicates")
    parser.add_argument("--zipf-exponent", type=float, default=1.0)
    parser.add_argument("--seed", type=int, default=42)
    parser.add_argument("--timeout", type=float, default=30.0)
    args = parser.parse_args()

    manifest = build(args.out, args.ndcs, args.occurrences, args.unique_ratio,
                     args.zipf_exponent, args.seed, args.timeout)
    print(json.dumps(manifest, indent=2))


if __name__ == "__main__":
    main()
