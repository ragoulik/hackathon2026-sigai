"""DocumentDB clients with native authentication or renewable Entra OIDC tokens."""

from __future__ import annotations

import json
import os
import time
from urllib.parse import parse_qsl, urlsplit

from azure.core.credentials import TokenCredential
from azure.identity import AzureCliCredential, DefaultAzureCredential
from pymongo import MongoClient
from pymongo.auth_oidc import OIDCCallback, OIDCCallbackContext, OIDCCallbackResult

TOKEN_SCOPE = "https://ossrdbms-aad.database.windows.net/.default"


class AzureIdentityTokenCallback(OIDCCallback):
    def __init__(self, credential: TokenCredential):
        self.credential = credential

    def fetch(self, context: OIDCCallbackContext) -> OIDCCallbackResult:
        token = self.credential.get_token(TOKEN_SCOPE)
        return OIDCCallbackResult(
            access_token=token.token,
            expires_in_seconds=token.expires_on - time.time(),
        )


def create_client(uri: str, server_selection_timeout_ms: int = 30000) -> MongoClient:
    options = {key.lower(): value for key, value in parse_qsl(urlsplit(uri).query)}
    if options.get("authmechanism", "").upper() != "MONGODB-OIDC":
        return MongoClient(uri, serverSelectionTimeoutMS=server_selection_timeout_ms)

    credential_name = os.environ.get("MONGO_ENTRA_CREDENTIAL", "default")
    credential: TokenCredential
    if credential_name == "azure-cli":
        credential = AzureCliCredential(
            tenant_id=os.environ.get("AZURE_TENANT_ID", ""),
            process_timeout=30,
        )
    elif credential_name == "default":
        credential = DefaultAzureCredential()
    else:
        raise ValueError("MONGO_ENTRA_CREDENTIAL must be 'azure-cli' or 'default'")

    return MongoClient(
        uri,
        tls=True,
        serverSelectionTimeoutMS=server_selection_timeout_ms,
        authMechanismProperties={"OIDC_CALLBACK": AzureIdentityTokenCallback(credential)},
    )


def main() -> None:
    uri = os.environ.get("MONGO_URI")
    if not uri:
        raise SystemExit("MONGO_URI is not set")
    with create_client(uri) as client:
        ping = client.admin.command("ping")
        collections = client["sigmvp"].list_collection_names()
        print(json.dumps({
            "ping": ping["ok"],
            "database": "sigmvp",
            "collection_count": len(collections),
        }, indent=2))


if __name__ == "__main__":
    main()
