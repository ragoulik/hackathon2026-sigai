"""Short-lived translation cache keyed on the prescription and retrieval settings.

Layout and policy are part of the key. Without them a cached baseline result would
be served for a sig_centric request, which would silently invalidate any comparison
between the two layouts.

Expiry is enforced on read rather than trusting the TTL monitor, which sweeps
lazily and can leave expired documents readable for minutes.
"""

from __future__ import annotations

import hashlib
import json
import time
from datetime import datetime, timedelta, timezone

COLLECTION = "translation_cache"
DEFAULT_TTL_SECONDS = 3600


def cache_key(ndc: str, doctors_sig: str, layout: str, policy: str, example_limit: int) -> str:
    canonical = json.dumps(
        {
            "ndc": ndc,
            "doctors_sig": doctors_sig,
            "layout": layout,
            "policy": policy,
            "example_limit": example_limit,
        },
        sort_keys=True,
        separators=(",", ":"),
    )
    return hashlib.sha256(canonical.encode("utf-8")).hexdigest()


def ensure_index(db) -> None:
    db[COLLECTION].create_index("expires_at", expireAfterSeconds=0)


def get(db, key: str, ttl_seconds: int = DEFAULT_TTL_SECONDS) -> dict | None:
    doc = db[COLLECTION].find_one({"_id": key})
    if not doc:
        return None
    stored = doc.get("created_at")
    if not isinstance(stored, datetime):
        return None
    age = (datetime.now(timezone.utc) - stored.replace(tzinfo=timezone.utc)).total_seconds()
    if age > ttl_seconds:
        return None
    doc["age_seconds"] = round(age, 1)
    return doc


def put(db, key: str, value: dict, ttl_seconds: int = DEFAULT_TTL_SECONDS) -> None:
    now = datetime.now(timezone.utc)
    db[COLLECTION].replace_one(
        {"_id": key},
        {
            "_id": key,
            "created_at": now,
            "expires_at": now + timedelta(seconds=ttl_seconds),
            "cached_at_epoch": time.time(),
            **value,
        },
        upsert=True,
    )
