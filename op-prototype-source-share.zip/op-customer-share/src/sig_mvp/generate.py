"""Builds the customer's current state: baseline_occurrences with a vector on every row.

Runs as an Azure Container Apps Job. Embeds once per occurrence rather than once
per unique string, because per-occurrence embedding is the cost the customer pays
today and the cost deduplication removes. The measured figure is reported so the
saving is evidence rather than assertion.

Writes only the baseline layout. The sig-centric layout is produced by
sig_mvp.migrate, which is the path the customer would actually run.
"""

from __future__ import annotations

import argparse
import json
import os
import sys
import time
from pathlib import Path

from pymongo.errors import BulkWriteError

from sig_mvp import corpus
from sig_mvp.database import create_client
from sig_mvp.embed import DIMENSIONS, PubMedBertBackend, StubBackend
from sig_mvp.reports import record_report

DB_NAME = "sigmvp"
COLLECTION = "baseline_occurrences"


def log(message: str) -> None:
    print(f"[{time.strftime('%H:%M:%S')}] {message}", flush=True)


def read_occurrences(path: Path):
    with path.open(encoding="utf-8") as fh:
        for line in fh:
            if line.strip():
                yield json.loads(line)


def create_vector_index(db, rows: int, kind: str) -> dict:
    options = {"kind": kind, "similarity": "COS", "dimensions": DIMENSIONS}
    if kind == "vector-ivf":
        options["numLists"] = max(1, min(rows // 1000, 1000))
    return db.command({
        "createIndexes": COLLECTION,
        "indexes": [{
            "name": "baseline_vec",
            "key": {"embeddings": "cosmosSearch"},
            "cosmosSearchOptions": options,
        }],
    })


def run(args) -> dict:
    uri = os.environ.get("MONGO_URI")
    if not uri:
        raise SystemExit("MONGO_URI is not set")

    data_dir = Path(args.data)
    occ_path = data_dir / "occurrences.jsonl"

    if args.reuse_corpus and occ_path.exists():
        manifest = json.loads((data_dir / "manifest.json").read_text(encoding="utf-8"))
        log(f"reusing corpus: {manifest['occurrence_count']} occurrences")
    else:
        log(f"generating corpus: {args.occurrences} occurrences across {args.ndcs} NDCs")
        manifest = corpus.build(data_dir, args.ndcs, args.occurrences, args.unique_ratio,
                                args.zipf_exponent, args.seed, args.timeout)
        log(f"corpus built: unique={manifest['unique_sig_count']} "
            f"duplicate_rate={manifest['duplicate_rate']}")

    backend = StubBackend() if args.backend == "stub" else PubMedBertBackend(args.revision)
    log(f"embedding backend: {backend.name} config={backend.embedding_config_id}")

    if args.backend != "stub":
        import torch
        threads = args.threads or os.cpu_count() or 1
        torch.set_num_threads(threads)
        log(f"torch threads: {threads}")

    client = create_client(uri)
    client.admin.command("ping")
    db = client[DB_NAME]

    if args.drop:
        log(f"dropping {COLLECTION}")
        db[COLLECTION].drop()

    existing: set[str] = set()
    if args.resume:
        existing = {d["_id"] for d in db[COLLECTION].find({}, {"_id": 1})}
        log(f"resume: {len(existing)} rows already present")

    total = manifest["occurrence_count"]
    embedded = 0
    inserted = 0
    skipped = 0
    started = time.perf_counter()
    embed_seconds = 0.0
    batch: list[dict] = []

    def flush(docs: list[dict]) -> int:
        if not docs:
            return 0
        try:
            db[COLLECTION].insert_many(docs, ordered=False)
            return len(docs)
        except BulkWriteError as exc:
            # Duplicate keys are expected when resuming over a partially written batch.
            duplicates = sum(1 for e in exc.details.get("writeErrors", []) if e.get("code") == 11000)
            if duplicates != len(exc.details.get("writeErrors", [])):
                raise
            return len(docs) - duplicates

    for occ in read_occurrences(occ_path):
        if occ["_id"] in existing:
            skipped += 1
            continue
        batch.append(occ)
        if len(batch) < args.batch_size:
            continue

        t0 = time.perf_counter()
        vectors = backend.encode_batch([o["doctors_sig"] for o in batch]) \
            if hasattr(backend, "encode_batch") else [backend.encode(o["doctors_sig"]) for o in batch]
        embed_seconds += time.perf_counter() - t0
        embedded += len(batch)

        inserted += flush([
            {**o, "embeddings": v, "embedding_config_id": backend.embedding_config_id}
            for o, v in zip(batch, vectors)
        ])
        batch = []

        if embedded % (args.batch_size * 10) == 0:
            elapsed = time.perf_counter() - started
            rate = embedded / max(elapsed, 1e-6)
            remaining = max(total - skipped - embedded, 0)
            log(f"{embedded}/{total - skipped} embedded  {rate:.0f}/s  "
                f"eta {remaining / max(rate, 1e-6) / 60:.1f} min")

    if batch:
        t0 = time.perf_counter()
        vectors = backend.encode_batch([o["doctors_sig"] for o in batch]) \
            if hasattr(backend, "encode_batch") else [backend.encode(o["doctors_sig"]) for o in batch]
        embed_seconds += time.perf_counter() - t0
        embedded += len(batch)
        inserted += flush([
            {**o, "embeddings": v, "embedding_config_id": backend.embedding_config_id}
            for o, v in zip(batch, vectors)
        ])

    log("creating indexes")
    db[COLLECTION].create_index([("ndc", 1)])
    index_result = create_vector_index(db, total, args.kind)

    count = db[COLLECTION].count_documents({})
    wall = time.perf_counter() - started
    report = {
        "collection": COLLECTION,
        "occurrences_expected": total,
        "documents_in_collection": count,
        "counts_match": count == total,
        "embeddings_computed": embedded,
        "rows_skipped_on_resume": skipped,
        "rows_inserted": inserted,
        "unique_sig_count": manifest["unique_sig_count"],
        "duplicate_rate": manifest["duplicate_rate"],
        # What deduplication would have cost, against what per-occurrence embedding did cost.
        "embeddings_avoidable_by_dedup": embedded - manifest["unique_sig_count"]
        if embedded else 0,
        "embed_seconds": round(embed_seconds, 1),
        "embed_rate_per_second": round(embedded / embed_seconds, 1) if embed_seconds else None,
        "wall_seconds": round(wall, 1),
        "embedding_backend": backend.name,
        "embedding_config_id": backend.embedding_config_id,
        "vector_index_kind": args.kind,
        "vector_index_ok": index_result.get("ok") == 1,
        "vector_bytes_estimate": count * DIMENSIONS * 8,
    }
    report["report_id"] = record_report(db, "generate", report)
    client.close()
    return report


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--data", default="/tmp/data")
    parser.add_argument("--ndcs", type=int, default=2000)
    parser.add_argument("--occurrences", type=int, default=100000)
    parser.add_argument("--unique-ratio", type=float, default=0.30)
    parser.add_argument("--zipf-exponent", type=float, default=1.0)
    parser.add_argument("--seed", type=int, default=42)
    parser.add_argument("--timeout", type=float, default=30.0)
    parser.add_argument("--backend", choices=["pubmedbert", "stub"], default="pubmedbert")
    parser.add_argument("--revision", default=None)
    parser.add_argument("--batch-size", type=int, default=64)
    parser.add_argument("--threads", type=int, default=0)
    parser.add_argument("--kind", default="vector-ivf",
                        choices=["vector-ivf", "vector-hnsw", "vector-diskann"])
    parser.add_argument("--drop", action="store_true")
    parser.add_argument("--resume", action="store_true")
    parser.add_argument("--reuse-corpus", action="store_true")
    args = parser.parse_args()

    report = run(args)
    log("done")
    print(json.dumps(report, indent=2), flush=True)
    if not report["counts_match"]:
        sys.exit(1)


if __name__ == "__main__":
    main()
