"""Smoke test: run one query through both layouts and compare the ordered results."""

from __future__ import annotations

import argparse
import json
import os
from pathlib import Path

from sig_mvp.database import create_client
from sig_mvp.embed import PubMedBertBackend
from sig_mvp.retrieval import DB_NAME, Policy, retrieve


def pick_example(data_dir: Path) -> tuple[str, str]:
    """Choose a SIG that appears under several NDCs, so the comparison is meaningful."""
    with (data_dir / "occurrences.jsonl").open(encoding="utf-8") as fh:
        first = json.loads(fh.readline())
    return first["ndc"], first["doctors_sig"]


def render(rows: list[dict]) -> str:
    if not rows:
        return "    (no results)"
    lines = []
    for i, row in enumerate(rows, 1):
        lines.append(
            f"    {i}. {row['_id']}  ndc={row['ndc']}  score={row['score']:.6f}\n"
            f"       {row.get('translated_sig')}"
        )
    return "\n".join(lines)


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--data", type=Path, default=Path("data"))
    parser.add_argument("--ndc")
    parser.add_argument("--sig")
    parser.add_argument("--policy", default="postfilter_reference",
                        choices=["postfilter_reference", "ndc_prefilter_experiment"])
    parser.add_argument("--limit", type=int, default=5)
    args = parser.parse_args()

    ndc, sig = (args.ndc, args.sig)
    if not ndc or not sig:
        ndc, sig = pick_example(args.data)

    uri = os.environ.get("MONGO_URI")
    if not uri:
        raise SystemExit("MONGO_URI is not set")

    print(f"query ndc : {ndc}")
    print(f"query sig : {sig}")
    print(f"policy    : {args.policy}\n")

    vector = PubMedBertBackend().encode(sig)
    policy = Policy(name=args.policy, example_limit=args.limit)

    client = create_client(uri)
    db = client[DB_NAME]
    results = {}
    for layout in ("baseline", "sig_centric"):
        rows = retrieve(db, layout, vector, ndc, policy)
        results[layout] = rows
        print(f"[{layout}]")
        print(render(rows))
        print()

    baseline_ids = [str(r["_id"]) for r in results["baseline"]]
    shared_ids = [str(r["_id"]) for r in results["sig_centric"]]
    leaked = [r["ndc"] for r in results["sig_centric"] if r["ndc"] != ndc]

    print("comparison")
    print(f"  same ordered occurrence ids : {baseline_ids == shared_ids}")
    print(f"  baseline ids                : {baseline_ids}")
    print(f"  sig_centric ids             : {shared_ids}")
    print(f"  ndc leakage after filtering : {len(leaked)}")
    client.close()


if __name__ == "__main__":
    main()
