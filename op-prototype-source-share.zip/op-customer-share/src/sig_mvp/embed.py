"""Embedding pass: one 768-dimensional vector per unique exact doctors_sig string.

The sharing key is strict text identity plus the embedding configuration id. No
lowercasing, punctuation stripping or fuzzy matching is applied to that key.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import struct
from pathlib import Path

MODEL_REPO = "microsoft/BiomedNLP-BiomedBERT-base-uncased-abstract"
# Pinned immutable revision; also what the container image caches, so offline loads resolve.
MODEL_REVISION = "d673b8835373c6fa116d6d8006b33d48734e305d"
MAX_TOKENS = 512
DIMENSIONS = 768


class InputTooLongError(ValueError):
    pass


class EmptyEmbeddingInputError(ValueError):
    pass


def config_id(payload: dict) -> str:
    canonical = json.dumps(payload, sort_keys=True, separators=(",", ":"))
    return hashlib.sha256(canonical.encode("utf-8")).hexdigest()[:32]


def sig_id(text: str, embedding_config_id: str) -> str:
    canonical = json.dumps(
        {"embedding_config_id": embedding_config_id, "embedding_input": text},
        sort_keys=True,
        separators=(",", ":"),
    )
    return hashlib.sha256(canonical.encode("utf-8")).hexdigest()


class StubBackend:
    """Deterministic pseudo-vectors. Plumbing only; carries no semantic meaning."""

    name = "stub-not-real"

    def __init__(self) -> None:
        self.config = {
            "backend": self.name,
            "dimensions": DIMENSIONS,
            "normalization": "l2",
            "input_field": "doctors_sig",
            "semantic": False,
        }
        self.embedding_config_id = config_id(self.config)

    def encode(self, text: str) -> list[float]:
        if not text.strip():
            raise EmptyEmbeddingInputError(text)
        raw = bytearray()
        counter = 0
        while len(raw) < DIMENSIONS * 4:
            raw += hashlib.sha256(f"{text}|{counter}".encode("utf-8")).digest()
            counter += 1
        values = [
            struct.unpack_from("<i", bytes(raw), i * 4)[0] / 2147483648.0
            for i in range(DIMENSIONS)
        ]
        norm = sum(v * v for v in values) ** 0.5
        if norm == 0.0:
            raise EmptyEmbeddingInputError(text)
        return [v / norm for v in values]


class PubMedBertBackend:
    """Masked mean pooling over content tokens, L2-normalized, CPU float32."""

    name = "pubmedbert"

    def __init__(self, revision: str | None = None) -> None:
        import torch
        from transformers import AutoModel, AutoTokenizer

        revision = revision or MODEL_REVISION
        self.torch = torch
        self.tokenizer = AutoTokenizer.from_pretrained(MODEL_REPO, revision=revision)
        self.model = AutoModel.from_pretrained(MODEL_REPO, revision=revision)
        self.model.eval()
        self.revision = getattr(self.model.config, "_commit_hash", revision)
        self.config = {
            "backend": self.name,
            "model_repo": MODEL_REPO,
            "model_revision": self.revision,
            "dimensions": DIMENSIONS,
            "pooling": "masked_mean_content_tokens",
            "special_token_policy": "excluded",
            "length_policy": f"reject_over_{MAX_TOKENS}",
            "normalization": "l2",
            "numeric": "float32",
            "input_field": "doctors_sig",
            "semantic": True,
        }
        self.embedding_config_id = config_id(self.config)

    def encode(self, text: str) -> list[float]:
        torch = self.torch
        tokens = self.tokenizer(
            text,
            return_tensors="pt",
            return_special_tokens_mask=True,
            truncation=False,
        )
        special = tokens.pop("special_tokens_mask")
        if tokens["input_ids"].shape[1] > MAX_TOKENS:
            raise InputTooLongError(text)
        content = tokens["attention_mask"].bool() & ~special.bool()
        if not bool(content.any()):
            raise EmptyEmbeddingInputError(text)
        with torch.inference_mode():
            hidden = self.model(**tokens).last_hidden_state
            pooled = (hidden * content.unsqueeze(-1)).sum(1) / content.sum(1, keepdim=True)
            norm = pooled.norm(dim=1, keepdim=True)
            if not bool(torch.isfinite(norm).all()) or float(norm.min()) == 0.0:
                raise EmptyEmbeddingInputError(text)
            vector = (pooled / norm)[0]
        values = [float(v) for v in vector]
        if len(values) != DIMENSIONS or not all(map(lambda v: v == v and abs(v) != float("inf"), values)):
            raise ValueError("non-finite or wrong-dimension vector")
        return values

    def encode_batch(self, texts: list[str]) -> list[list[float]]:
        """Same pooling as encode, batched. Padding is excluded by the attention mask."""
        torch = self.torch
        if not texts:
            return []
        tokens = self.tokenizer(
            texts,
            return_tensors="pt",
            return_special_tokens_mask=True,
            padding=True,
            truncation=False,
        )
        special = tokens.pop("special_tokens_mask")
        if tokens["input_ids"].shape[1] > MAX_TOKENS:
            raise InputTooLongError(f"batch contains input over {MAX_TOKENS} tokens")
        content = tokens["attention_mask"].bool() & ~special.bool()
        if not bool(content.any(dim=1).all()):
            raise EmptyEmbeddingInputError("batch contains an input with no content tokens")
        with torch.inference_mode():
            hidden = self.model(**tokens).last_hidden_state
            mask = content.unsqueeze(-1)
            pooled = (hidden * mask).sum(1) / content.sum(1, keepdim=True)
            norm = pooled.norm(dim=1, keepdim=True)
            if not bool(torch.isfinite(norm).all()) or float(norm.min()) == 0.0:
                raise EmptyEmbeddingInputError("batch produced a zero or non-finite vector")
            vectors = pooled / norm
        return [[float(v) for v in row] for row in vectors]


def run(data_dir: Path, backend_name: str, revision: str | None) -> dict:
    occ_path = data_dir / "occurrences.jsonl"
    manifest_path = data_dir / "manifest.json"
    occurrences = [json.loads(line) for line in occ_path.read_text(encoding="utf-8").splitlines()]

    backend = PubMedBertBackend(revision) if backend_name == "pubmedbert" else StubBackend()

    membership: dict[str, set[str]] = {}
    for occ in occurrences:
        membership.setdefault(occ["doctors_sig"], set()).add(occ["ndc"])

    vectors_path = data_dir / "sig_vectors.jsonl"
    with vectors_path.open("w", encoding="utf-8") as fh:
        for text in sorted(membership):
            fh.write(json.dumps({
                "_id": sig_id(text, backend.embedding_config_id),
                "dataset_id": occurrences[0]["dataset_id"],
                "embedding_input": text,
                "embedding_config_id": backend.embedding_config_id,
                "embeddings": backend.encode(text),
                "ndcs": sorted(membership[text]),
                "synthetic": True,
                "clinical_use": False,
            }, ensure_ascii=False) + "\n")

    manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
    manifest["embedding_backend"] = backend.name
    manifest["embedding_config_id"] = backend.embedding_config_id
    manifest["embedding_config"] = backend.config
    manifest["vector_count"] = len(membership)
    manifest["vectors_are_semantic"] = backend.config["semantic"]
    manifest_path.write_text(json.dumps(manifest, indent=2) + "\n", encoding="utf-8")
    return manifest


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--data", type=Path, default=Path("data"))
    parser.add_argument("--backend", choices=["pubmedbert", "stub"], default="pubmedbert")
    parser.add_argument("--revision", default=None)
    args = parser.parse_args()

    manifest = run(args.data, args.backend, args.revision)
    print(json.dumps({k: manifest[k] for k in (
        "embedding_backend", "embedding_config_id", "vector_count",
        "occurrence_count", "vectors_are_semantic")}, indent=2))


if __name__ == "__main__":
    main()
