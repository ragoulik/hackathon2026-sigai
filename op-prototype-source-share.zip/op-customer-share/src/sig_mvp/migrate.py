"""Migrates baseline_occurrences to the sig-centric layout, in place, phase by phase.

This is the script the customer would run against their own data, so it is
non-destructive to the source collection, idempotent, resumable, and it verifies
rather than assumes.

Phases
  1  sig_vectors          one document per unique exact SIG string, holding the vector
  2  ndc_sig_occurrences  one document per occurrence, referencing sig_vectors, no vector
  3  indexes              vector index on sig_vectors plus lookup indexes
  4  verify               counts reconcile and retrieval returns the same examples

The dedup key is the exact SIG string. Two occurrences with identical text are
assumed to share a vector; where they do not, the divergence is reported instead
of being silently resolved, because that indicates embedding drift in the source.
"""

from __future__ import annotations

import argparse
import json
import os
import sys
import time

from sig_mvp.corpus import sig_key
from sig_mvp.database import create_client
from sig_mvp.embed import DIMENSIONS
from sig_mvp.reports import record_report

DB_NAME = "sigmvp"
SOURCE = "baseline_occurrences"
VECTORS = "sig_vectors"
OCCURRENCES = "ndc_sig_occurrences"
STATE = "migration_state"


def log(message: str) -> None:
    print(f"[{time.strftime('%H:%M:%S')}] {message}", flush=True)


def phase_done(db, phase: str) -> bool:
    return db[STATE].find_one({"_id": phase}) is not None


def mark_done(db, phase: str, detail: dict) -> None:
    db[STATE].replace_one(
        {"_id": phase},
        {"_id": phase, "completed_at": time.strftime("%Y-%m-%dT%H:%M:%SZ"), "detail": detail},
        upsert=True,
    )


def build_occurrences(db, batch_size: int) -> dict:
    """Phase 2 first pass: map every occurrence to its sig_id without reading vectors.

    Vectors are excluded from the projection because reading them for every row
    would move gigabytes for data already present in the source collection.
    """
    representatives: dict[str, str] = {}
    written = 0
    buffer = []
    cursor = db[SOURCE].find(
        {}, {"_id": 1, "ndc": 1, "ndc_original": 1, "doctors_sig": 1, "translated_sig": 1,
             "dataset_id": 1, "context": 1, "Rx_create_week": 1, "weighting_count": 1,
             "UNITS_PER_DAY": 1, "provenance": 1, "synthetic": 1, "clinical_use": 1,
             "embedding_config_id": 1}
    ).batch_size(batch_size)

    for occ in cursor:
        key = sig_key(occ["doctors_sig"])
        representatives.setdefault(key, occ["_id"])
        doc = {k: v for k, v in occ.items() if k != "doctors_sig"}
        doc["sig_id"] = key
        buffer.append(doc)
        if len(buffer) >= batch_size:
            db[OCCURRENCES].bulk_write(
                [_upsert(d) for d in buffer], ordered=False
            )
            written += len(buffer)
            buffer = []
            if written % (batch_size * 20) == 0:
                log(f"  occurrences mapped: {written}")

    if buffer:
        db[OCCURRENCES].bulk_write([_upsert(d) for d in buffer], ordered=False)
        written += len(buffer)

    return {"occurrences_written": written, "unique_sigs": len(representatives),
            "representatives": representatives}


def _upsert(doc: dict):
    from pymongo import ReplaceOne
    return ReplaceOne({"_id": doc["_id"]}, doc, upsert=True)


def build_vectors(db, representatives: dict[str, str], batch_size: int) -> dict:
    """Phase 1: copy one vector per unique SIG string out of the source rows."""
    from pymongo import ReplaceOne

    membership: dict[str, set[str]] = {}
    for row in db[OCCURRENCES].find({}, {"sig_id": 1, "ndc": 1}):
        membership.setdefault(row["sig_id"], set()).add(row["ndc"])

    by_source_id = {source_id: key for key, source_id in representatives.items()}
    source_ids = list(by_source_id)
    written = 0

    # Fetched in chunks; one find_one per unique SIG would be tens of thousands of round trips.
    for start in range(0, len(source_ids), batch_size):
        chunk = source_ids[start:start + batch_size]
        rows = list(db[SOURCE].find(
            {"_id": {"$in": chunk}},
            {"doctors_sig": 1, "embeddings": 1, "embedding_config_id": 1, "dataset_id": 1},
        ))
        if len(rows) != len(chunk):
            missing = set(chunk) - {r["_id"] for r in rows}
            raise SystemExit(f"representative occurrences vanished during migration: {sorted(missing)[:5]}")

        operations = []
        for source in rows:
            key = by_source_id[source["_id"]]
            ndcs = sorted(membership.get(key, set()))
            operations.append(ReplaceOne({"_id": key}, {
                "_id": key,
                "dataset_id": source.get("dataset_id"),
                "embedding_input": source["doctors_sig"],
                "embedding_config_id": source.get("embedding_config_id"),
                "embeddings": source["embeddings"],
                "ndcs": ndcs,
                "ndc_count": len(ndcs),
                "synthetic": True,
                "clinical_use": False,
            }, upsert=True))

        db[VECTORS].bulk_write(operations, ordered=False)
        written += len(operations)
        if written % (batch_size * 20) == 0:
            log(f"  vectors written: {written}")

    return {"vectors_written": written}


def check_divergence(db, sample: int) -> dict:
    """Are identical SIG strings really carrying identical vectors in the source?

    Silently picking a representative would hide embedding drift, which is a real
    risk in a corpus accumulated over a year of model versions.
    """
    checked = 0
    diverged = []
    pipeline = [
        {"$group": {"_id": "$sig_id", "ids": {"$push": "$_id"}, "n": {"$sum": 1}}},
        {"$match": {"n": {"$gte": 2}}},
        {"$limit": sample},
    ]
    for group in db[OCCURRENCES].aggregate(pipeline, allowDiskUse=True):
        ids = group["ids"][:2]
        rows = list(db[SOURCE].find({"_id": {"$in": ids}}, {"embeddings": 1}))
        if len(rows) < 2:
            continue
        checked += 1
        a, b = rows[0]["embeddings"], rows[1]["embeddings"]
        if len(a) != len(b) or max(abs(x - y) for x, y in zip(a, b)) > 1e-6:
            diverged.append(group["_id"])
    return {
        "groups_checked": checked,
        "groups_with_divergent_vectors": len(diverged),
        "example_divergent_sig_ids": diverged[:5],
    }


def create_indexes(db, vector_count: int, kind: str) -> dict:
    db[OCCURRENCES].create_index([("sig_id", 1), ("ndc", 1)])
    db[OCCURRENCES].create_index([("ndc", 1), ("sig_id", 1)])
    # DocumentDB rejects a vector search filtered on a path that has no index of its own.
    db[VECTORS].create_index([("ndcs", 1)])
    options = {"kind": kind, "similarity": "COS", "dimensions": DIMENSIONS}
    if kind == "vector-ivf":
        options["numLists"] = max(1, min(vector_count // 1000, 1000))
    result = db.command({
        "createIndexes": VECTORS,
        "indexes": [{
            "name": "sig_vectors_vec",
            "key": {"embeddings": "cosmosSearch"},
            "cosmosSearchOptions": options,
        }],
    })
    return {"vector_index_ok": result.get("ok") == 1, "kind": kind,
            "ndcs_filter_index": True}


def verify(db, sample: int) -> dict:
    from sig_mvp.retrieval import Policy, retrieve_baseline, retrieve_sig_centric

    source_count = db[SOURCE].count_documents({})
    occ_count = db[OCCURRENCES].count_documents({})
    vec_count = db[VECTORS].count_documents({})
    orphans = db[OCCURRENCES].aggregate([
        {"$lookup": {"from": VECTORS, "localField": "sig_id",
                     "foreignField": "_id", "as": "v"}},
        {"$match": {"v": {"$size": 0}}},
        {"$limit": 5},
        {"$project": {"_id": 1, "sig_id": 1}},
    ])
    orphan_list = list(orphans)

    policy = Policy(name="ndc_prefilter")
    agreements = 0
    compared = 0
    for probe in db[SOURCE].aggregate([{"$sample": {"size": sample}},
                                       {"$project": {"embeddings": 1, "ndc": 1}}]):
        base = retrieve_baseline(db, probe["embeddings"], probe["ndc"], policy)
        sigc = retrieve_sig_centric(db, probe["embeddings"], probe["ndc"], policy)
        compared += 1
        if {e["translated_sig"] for e in base} == {e["translated_sig"] for e in sigc}:
            agreements += 1

    return {
        "source_documents": source_count,
        "occurrence_documents": occ_count,
        "vector_documents": vec_count,
        "occurrence_counts_match": source_count == occ_count,
        "orphan_occurrences": orphan_list,
        "retrieval_probes": compared,
        "retrieval_agreement": agreements,
        "retrieval_agreement_rate": round(agreements / compared, 4) if compared else None,
        "vector_bytes_baseline": source_count * DIMENSIONS * 8,
        "vector_bytes_sig_centric": vec_count * DIMENSIONS * 8,
        "vector_storage_reduction": round(1 - vec_count / source_count, 4) if source_count else None,
    }


def load_representatives(db) -> dict[str, str]:
    """Recover one source occurrence per unique sig, so a resumed run can skip phase 2."""
    return {
        row["_id"]: row["rep"]
        for row in db[OCCURRENCES].aggregate(
            [{"$group": {"_id": "$sig_id", "rep": {"$first": "$_id"}}}], allowDiskUse=True
        )
    }


def run(args) -> dict:
    uri = os.environ.get("MONGO_URI")
    if not uri:
        raise SystemExit("MONGO_URI is not set")

    client = create_client(uri)
    client.admin.command("ping")
    db = client[DB_NAME]

    if db[SOURCE].estimated_document_count() == 0:
        raise SystemExit(f"{SOURCE} is empty; run sig_mvp.generate first")

    if args.restart:
        log("restart: clearing derived collections and migration state")
        db[VECTORS].drop()
        db[OCCURRENCES].drop()
        db[STATE].drop()

    started = time.perf_counter()
    report: dict = {"phases": {}}

    if phase_done(db, "occurrences") and not args.restart:
        log("phase 2/4: already complete, recovering sig representatives")
        representatives = load_representatives(db)
        mapping = {"occurrences_written": db[OCCURRENCES].estimated_document_count(),
                   "unique_sigs": len(representatives), "skipped": True}
    else:
        log("phase 2/4: mapping occurrences to sig ids")
        mapping = build_occurrences(db, args.batch_size)
        representatives = mapping.pop("representatives")
        mark_done(db, "occurrences", mapping)
    report["phases"]["occurrences"] = mapping
    log(f"  {mapping['occurrences_written']} occurrences, {mapping['unique_sigs']} unique sigs")

    if phase_done(db, "vectors") and not args.restart:
        log("phase 1/4: already complete, skipping")
        report["phases"]["vectors"] = {"vectors_written": db[VECTORS].estimated_document_count(),
                                       "skipped": True}
    else:
        log("phase 1/4: writing one vector per unique sig")
        report["phases"]["vectors"] = build_vectors(db, representatives, args.batch_size)
        mark_done(db, "vectors", report["phases"]["vectors"])
    log(f"  {report['phases']['vectors']['vectors_written']} vectors")

    if args.divergence_sample > 0:
        log("checking for divergent vectors on identical sig text")
        report["divergence"] = check_divergence(db, args.divergence_sample)
        log(f"  {report['divergence']['groups_with_divergent_vectors']} divergent of "
            f"{report['divergence']['groups_checked']} checked")

    log("phase 3/4: creating indexes")
    report["phases"]["indexes"] = create_indexes(db, mapping["unique_sigs"], args.kind)
    mark_done(db, "indexes", report["phases"]["indexes"])

    log("phase 4/4: verifying")
    report["verify"] = verify(db, args.verify_sample)
    mark_done(db, "verify", report["verify"])

    report["wall_seconds"] = round(time.perf_counter() - started, 1)
    report["source_collection_untouched"] = True
    report["report_id"] = record_report(db, "migrate", report)
    client.close()
    return report


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--batch-size", type=int, default=500)
    parser.add_argument("--kind", default="vector-ivf",
                        choices=["vector-ivf", "vector-hnsw", "vector-diskann"])
    parser.add_argument("--divergence-sample", type=int, default=200)
    parser.add_argument("--verify-sample", type=int, default=25)
    parser.add_argument("--restart", action="store_true",
                        help="drop derived collections and migrate from scratch")
    args = parser.parse_args()

    report = run(args)
    log("migration complete")
    print(json.dumps(report, indent=2, default=str), flush=True)
    verify_block = report["verify"]
    if not verify_block["occurrence_counts_match"] or verify_block["orphan_occurrences"]:
        sys.exit(1)


if __name__ == "__main__":
    main()
