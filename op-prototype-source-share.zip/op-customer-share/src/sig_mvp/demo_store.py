"""NDC lookup and demo test-run persistence for the UI.

Lookups read baseline_occurrences, which is the customer's current model and is
present whether or not the sig-centric migration has run.
"""

from __future__ import annotations

import uuid
from datetime import datetime, timezone
from typing import Any

RUNS_COLLECTION = "ui_test_runs"
SOURCE = "baseline_occurrences"
CATALOG = "ndc_catalog"


def ensure_catalog(db) -> int:
    """Materialize the distinct NDC list once; grouping 100k rows per keystroke is too slow."""
    existing = db[CATALOG].estimated_document_count()
    if existing:
        return existing
    rows = list(db[SOURCE].aggregate([
        {"$group": {
            "_id": "$ndc",
            "drug_name": {"$first": "$context.drug_name"},
            "drug_form": {"$first": "$context.drug_form"},
            "occurrences": {"$sum": 1},
        }},
    ], allowDiskUse=True))
    if rows:
        db[CATALOG].insert_many(rows, ordered=False)
    return len(rows)


def search_ndcs(db, query: str | None, limit: int = 20) -> list[dict]:
    """Prefix match on NDC, returning a drug label for display."""
    ensure_catalog(db)
    match: dict[str, Any] = {}
    if query:
        cleaned = "".join(ch for ch in query if ch.isdigit())
        if cleaned:
            match["_id"] = {"$regex": f"^{cleaned}"}
    return [
        {
            "ndc": row["_id"],
            "drug_name": row.get("drug_name") or "",
            "drug_form": row.get("drug_form") or "",
            "occurrences": row.get("occurrences", 0),
        }
        for row in db[CATALOG].find(match).sort("_id", 1).limit(limit)
    ]


def random_ndc(db) -> dict | None:
    ensure_catalog(db)
    rows = list(db[CATALOG].aggregate([{"$sample": {"size": 1}}]))
    if not rows:
        return None
    row = rows[0]
    return {
        "ndc": row["_id"],
        "drug_name": row.get("drug_name") or "",
        "drug_form": row.get("drug_form") or "",
    }


def sample_sigs(db, ndc: str, limit: int = 5) -> list[str]:
    rows = db[SOURCE].aggregate([
        {"$match": {"ndc": ndc}},
        {"$group": {"_id": "$doctors_sig"}},
        {"$limit": limit},
    ])
    return [r["_id"] for r in rows]


def save_run(db, payload: dict) -> str:
    run_id = uuid.uuid4().hex
    db[RUNS_COLLECTION].insert_one({
        "_id": run_id,
        "created_at": datetime.now(timezone.utc).isoformat(),
        **payload,
    })
    return run_id


def list_runs(db, limit: int = 50) -> list[dict]:
    rows = db[RUNS_COLLECTION].find(
        {}, {"trace": 0}
    ).sort("created_at", -1).limit(limit)
    return [{**r, "id": r.pop("_id")} for r in rows]


def get_run(db, run_id: str) -> dict | None:
    row = db[RUNS_COLLECTION].find_one({"_id": run_id})
    if row:
        row["id"] = row.pop("_id")
    return row
