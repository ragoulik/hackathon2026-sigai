"""Durable job reports.

The Container Apps environment has no log destination, so container stdout is
discarded. Job results are written to the database instead, which also makes them
queryable after the fact.
"""

from __future__ import annotations

import time

COLLECTION = "job_reports"


def record_report(db, job: str, report: dict) -> str:
    report_id = f"{job}-{time.strftime('%Y%m%dT%H%M%SZ', time.gmtime())}"
    db[COLLECTION].replace_one(
        {"_id": report_id},
        {"_id": report_id, "job": job,
         "created_at": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
         "report": report},
        upsert=True,
    )
    return report_id
