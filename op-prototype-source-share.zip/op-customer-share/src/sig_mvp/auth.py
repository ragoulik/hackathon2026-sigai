"""Entra JWT validation for API routes.

Replaces Container Apps EasyAuth so the SPA shell can be served unauthenticated
while every data endpoint still requires a valid token.
"""

from __future__ import annotations

import os
import time
from typing import Any

import httpx
import jwt
from fastapi import Header, HTTPException
from jwt import PyJWKClient


def _required_setting(name: str) -> str:
    value = os.environ.get(name, "").strip()
    if not value:
        raise RuntimeError(f"{name} must be configured")
    return value


TENANT_ID = _required_setting("AZURE_TENANT_ID")
API_AUDIENCE = _required_setting("API_AUDIENCE")
ISSUERS = {
    f"https://login.microsoftonline.com/{TENANT_ID}/v2.0",
    f"https://sts.windows.net/{TENANT_ID}/",
}
JWKS_URI = f"https://login.microsoftonline.com/{TENANT_ID}/discovery/v2.0/keys"

# Client apps permitted to call the API: the SPA and the managed-identity caller.
ALLOWED_CLIENT_IDS = {
    client_id.strip()
    for client_id in _required_setting("ALLOWED_CLIENT_IDS").split(",")
    if client_id.strip()
}

_jwk_client: PyJWKClient | None = None


def _jwks() -> PyJWKClient:
    global _jwk_client
    if _jwk_client is None:
        _jwk_client = PyJWKClient(JWKS_URI, cache_keys=True)
    return _jwk_client


def _decode(token: str) -> dict[str, Any]:
    key = _jwks().get_signing_key_from_jwt(token).key
    for audience in (API_AUDIENCE, API_AUDIENCE.removeprefix("api://")):
        try:
            claims = jwt.decode(
                token, key, algorithms=["RS256"], audience=audience,
                options={"verify_exp": True, "require": ["exp", "iss", "aud"]},
            )
        except jwt.InvalidAudienceError:
            continue
        if claims.get("iss") not in ISSUERS:
            raise HTTPException(status_code=401, detail="issuer not accepted")
        return claims
    raise HTTPException(status_code=401, detail="audience not accepted")


def require_token(authorization: str | None = Header(default=None)) -> dict[str, Any]:
    if not authorization or not authorization.lower().startswith("bearer "):
        raise HTTPException(status_code=401, detail="missing bearer token")
    token = authorization.split(" ", 1)[1].strip()
    try:
        claims = _decode(token)
    except HTTPException:
        raise
    except jwt.PyJWTError as exc:
        raise HTTPException(status_code=401, detail=f"invalid token: {type(exc).__name__}") from exc

    caller = claims.get("azp") or claims.get("appid")
    if ALLOWED_CLIENT_IDS and caller not in ALLOWED_CLIENT_IDS:
        raise HTTPException(status_code=403, detail="client application not allowed")
    return claims


def caller_label(claims: dict[str, Any]) -> str:
    return claims.get("preferred_username") or claims.get("oid") or "unknown"
