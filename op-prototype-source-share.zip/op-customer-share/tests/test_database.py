import os
import unittest
from unittest.mock import Mock, patch

from azure.core.credentials import AccessToken

from sig_mvp.database import AzureIdentityTokenCallback, TOKEN_SCOPE, create_client


class DatabaseClientTests(unittest.TestCase):
    @patch("sig_mvp.database.DefaultAzureCredential")
    @patch("sig_mvp.database.AzureCliCredential")
    @patch("sig_mvp.database.MongoClient")
    def test_native_auth_does_not_acquire_entra_credentials(self, mongo, cli, default):
        uri = "mongodb://localhost/?authMechanism=SCRAM-SHA-256"
        self.assertIs(create_client(uri, 15000), mongo.return_value)
        mongo.assert_called_once_with(uri, serverSelectionTimeoutMS=15000)
        cli.assert_not_called()
        default.assert_not_called()

    @patch.dict(os.environ, {
        "MONGO_ENTRA_CREDENTIAL": "azure-cli",
        "AZURE_TENANT_ID": "tenant",
    })
    @patch("sig_mvp.database.AzureCliCredential")
    @patch("sig_mvp.database.MongoClient")
    def test_entra_cli_uses_explicit_tenant_without_subscription(self, mongo, cli):
        uri = "mongodb+srv://example.invalid/?authMechanism=MONGODB-OIDC"
        create_client(uri)
        cli.assert_called_once_with(
            tenant_id="tenant", process_timeout=30,
        )
        properties = mongo.call_args.kwargs["authMechanismProperties"]
        self.assertIs(properties["OIDC_CALLBACK"].credential, cli.return_value)
        self.assertTrue(mongo.call_args.kwargs["tls"])

    @patch.dict(os.environ, {"MONGO_ENTRA_CREDENTIAL": "default"})
    @patch("sig_mvp.database.DefaultAzureCredential")
    @patch("sig_mvp.database.MongoClient")
    def test_default_credential_supports_hosted_identity(self, mongo, default):
        create_client("mongodb+srv://example.invalid/?authmechanism=MONGODB-OIDC")
        default.assert_called_once_with()
        callback = mongo.call_args.kwargs["authMechanismProperties"]["OIDC_CALLBACK"]
        self.assertIs(callback.credential, default.return_value)

    @patch.dict(os.environ, {"MONGO_ENTRA_CREDENTIAL": "invalid"})
    def test_invalid_credential_selection_is_not_silently_ignored(self):
        with self.assertRaises(ValueError):
            create_client("mongodb+srv://example.invalid/?authMechanism=MONGODB-OIDC")

    @patch("sig_mvp.database.time.time", return_value=100)
    def test_callback_returns_token_lifetime_and_refreshes(self, clock):
        credential = Mock()
        credential.get_token.side_effect = [
            AccessToken("first-test-token", 200),
            AccessToken("second-test-token", 300),
        ]
        callback = AzureIdentityTokenCallback(credential)
        first = callback.fetch(Mock())
        second = callback.fetch(Mock())
        self.assertEqual(first.access_token, "first-test-token")
        self.assertEqual(first.expires_in_seconds, 100)
        self.assertEqual(second.access_token, "second-test-token")
        self.assertEqual(second.expires_in_seconds, 200)
        credential.get_token.assert_called_with(TOKEN_SCOPE)

    def test_token_failure_propagates(self):
        credential = Mock()
        credential.get_token.side_effect = RuntimeError("authentication unavailable")
        with self.assertRaisesRegex(RuntimeError, "authentication unavailable"):
            AzureIdentityTokenCallback(credential).fetch(Mock())


if __name__ == "__main__":
    unittest.main()
