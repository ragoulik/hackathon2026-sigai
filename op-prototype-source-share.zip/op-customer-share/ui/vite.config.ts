import { defineConfig } from "vite";
import react from "@vitejs/plugin-react";

export default defineConfig({
    plugins: [react()],
    build: { outDir: "dist" },
    server: {
        port: 5173,
        proxy: { "/v1": { target: "http://127.0.0.1:8000", changeOrigin: true } },
    },
});
