export interface ArchBlock {
    id: string;
    title: string;
    subtitle: string;
    detail: string;
    tone: "input" | "compute" | "data" | "ai" | "output";
}

export const architecture: ArchBlock[] = [
    {
        id: "request",
        title: "Prescription request",
        subtitle: "NDC + doctor's SIG",
        tone: "input",
        detail:
            "The caller posts prescription attributes: rx_number, ndc, drug_name, strength, units and the raw doctors_sig. " +
            "Fields are validated with a Pydantic schema; a malformed batch is rejected with HTTP 422 before any paid work happens. " +
            "All data in this demo is synthetic and nonclinical.",
    },
    {
        id: "auth",
        title: "Entra authentication",
        subtitle: "MSAL token, JWT validated",
        tone: "compute",
        detail:
            "The SPA acquires an Entra token via MSAL for the API scope. The API validates the signature against Entra's JWKS, " +
            "plus audience, issuer and expiry, and checks the calling client application is allow-listed. " +
            "No API keys or passwords exist anywhere in the system.",
    },
    {
        id: "cache",
        title: "Translation cache",
        subtitle: "1 hour TTL, DocumentDB",
        tone: "data",
        detail:
            "Checked before any paid work. The key is a SHA-256 of ndc + doctors_sig + layout + policy + example_limit. " +
            "Layout and policy are part of the key deliberately: without them a cached baseline result would be served for a " +
            "sig_centric request and silently invalidate the comparison between the two layouts. " +
            "A hit skips embedding, vector search and generation entirely, so it costs one indexed read. " +
            "Expiry is checked on read rather than trusting the TTL monitor, which sweeps lazily and can leave expired entries readable. " +
            "Errors and null translations are never cached, so a transient model timeout cannot be replayed for an hour.",
    },
    {
        id: "embedding",
        title: "Embed the SIG",
        subtitle: "PubMedBERT, 768-d",
        tone: "compute",
        detail:
            "The exact doctors_sig string is embedded with microsoft/BiomedNLP-BiomedBERT-base-uncased-abstract, " +
            "pinned to revision d673b883. Masked mean pooling over content tokens (padding and special tokens excluded), " +
            "then L2 normalization, producing 768 float32 values. The model is baked into the container image, so cold starts need no network. " +
            "The incoming SIG is always embedded, never reused from storage: reusing a stored vector on an exact text match would skip " +
            "this stage for one layout only and bias any latency comparison.",
    },
    {
        id: "vector_search",
        title: "Vector search",
        subtitle: "Azure DocumentDB",
        tone: "data",
        detail:
            "The query vector is sent to Azure DocumentDB using $search with the cosmosSearch operator against a vector-ivf index. " +
            "baseline_occurrences stores a vector per occurrence and is the customer's current model. sig_centric stores one shared " +
            "vector per unique SIG string and expands matches back to their occurrences; it exists only after the migration has run. " +
            "Measured on 100,000 occurrences, NDC-prefiltered search costs roughly 3.7 s at p50 against about 48 ms for postfiltering, " +
            "because each NDC is a very small fraction of the index and the IVF scan degrades toward a full sweep.",
    },
    {
        id: "policy",
        title: "Ranking policy",
        subtitle: "NDC filter, threshold, limit",
        tone: "compute",
        detail:
            "ndc_prefilter is the reference policy and matches the customer's current API: constrain to the NDC, then search within it. " +
            "postfilter_reference mirrors the original diagram's left-to-right order, searching globally before filtering by NDC. " +
            "On duplicated data the two are not interchangeable: a global candidate cap is consumed by copies of the nearest few SIG " +
            "strings, so postfiltering can return nothing for the requested NDC. Scores are provider-defined, not raw cosine, " +
            "and are not confidence measures.",
    },
    {
        id: "generation",
        title: "Azure OpenAI",
        subtitle: "gpt-4o, structured output",
        tone: "ai",
        detail:
            "Retrieved history is assembled into a prompt where system policy is strictly separated from untrusted data. " +
            "The SIG, notes and retrieved examples are fenced as data, never instructions. The model must not introduce a dose, " +
            "frequency, duration or route that is not already present. Output is a strict JSON schema: translated_sig, needs_review, reason. " +
            "When retrieval finds no history a separate ungrounded policy produces a best-effort rewrite from the SIG text alone; " +
            "needs_review is then forced true in code rather than trusted from the model, and the reason is translated_without_history.",
    },
    {
        id: "response",
        title: "Response + review",
        subtitle: "translated_sig or needs_review",
        tone: "output",
        detail:
            "A supported translation is returned with needs_review false. Ambiguity, conflicting history, refusal, timeout or a schema " +
            "violation all return needs_review true with a bounded reason instead of an invented translation. " +
            "An ungrounded rewrite always carries needs_review true. " +
            "upd and cycle_days stay null: they are never inferred from strength or package size. " +
            "Successful translations are written to the cache; errors are not.",
    },
];

export const toneColor: Record<ArchBlock["tone"], string> = {
    input: "#6264a7",
    compute: "#0f6cbd",
    data: "#107c10",
    ai: "#a4262c",
    output: "#8661c5",
};
