import {
  Badge,
  Caption1,
  Subtitle2,
  Title3,
  makeStyles,
  shorthands,
  tokens,
} from "@fluentui/react-components";

const useStyles = makeStyles({
  row: { display: "flex", ...shorthands.gap("12px"), flexWrap: "wrap" },
  tile: {
    flexGrow: 1,
    flexBasis: "132px",
    minWidth: "120px",
    ...shorthands.padding("12px", "14px"),
    ...shorthands.borderRadius(tokens.borderRadiusMedium),
    ...shorthands.border("1px", "solid", tokens.colorNeutralStroke2),
    backgroundColor: tokens.colorNeutralBackground1,
    "@media (max-width: 600px)": { flexBasis: "calc(50% - 12px)", minWidth: "0px", ...shorthands.padding("10px", "12px") },
  },
  value: {
    fontSize: "22px",
    fontWeight: 600,
    lineHeight: "28px",
    "@media (max-width: 600px)": { fontSize: "18px", lineHeight: "24px" },
  },
  bar: {
    display: "flex",
    height: "10px",
    ...shorthands.borderRadius("5px"),
    overflow: "hidden",
    backgroundColor: tokens.colorNeutralBackground4,
    marginTop: "10px",
  },
  legend: { display: "flex", ...shorthands.gap("14px"), marginTop: "8px", flexWrap: "wrap" },
  legendItem: { display: "flex", alignItems: "center", ...shorthands.gap("6px") },
  swatch: { width: "10px", height: "10px", ...shorthands.borderRadius("2px") },
  banner: {
    display: "flex",
    alignItems: "center",
    ...shorthands.gap("12px"),
    ...shorthands.padding("10px", "14px"),
    ...shorthands.borderRadius(tokens.borderRadiusMedium),
    marginBottom: "14px",
    flexWrap: "wrap",
  },
  bannerDot: { width: "10px", height: "10px", ...shorthands.borderRadius("50%"), flexShrink: 0 },
  bannerLabel: { fontSize: "14px", fontWeight: 700, letterSpacing: "0.3px" },
});

const CACHE_HIT_COLOR = "#8764b8";
const CACHE_MISS_COLOR = "#797775";

export function CacheBanner({ hit, ageSeconds, ttlSeconds, cached }: {
  hit: boolean;
  ageSeconds?: number;
  ttlSeconds?: number;
  cached?: boolean;
}) {
  const styles = useStyles();
  const color = hit ? CACHE_HIT_COLOR : CACHE_MISS_COLOR;
  const remaining =
    hit && ttlSeconds !== undefined && ageSeconds !== undefined
      ? Math.max(Math.round(ttlSeconds - ageSeconds), 0)
      : undefined;

  return (
    <div className={styles.banner}
         style={{ backgroundColor: `${color}14`, border: `1px solid ${color}55` }}>
      <span className={styles.bannerDot} style={{ backgroundColor: color }} />
      <span className={styles.bannerLabel} style={{ color }}>
        {hit ? "CACHE HIT" : "CACHE MISS"}
      </span>
      <Caption1>
        {hit
          ? `Served from cache${ageSeconds !== undefined ? ` · stored ${Math.round(ageSeconds)}s ago` : ""}` +
            `${remaining !== undefined ? ` · expires in ${remaining}s` : ""}` +
            " · embedding, vector search and generation were skipped"
          : `Full pipeline ran${cached === false ? " · not cached" : " · result cached for the next hour"}`}
      </Caption1>
    </div>
  );
}

export interface StageTiming {
  id: string;
  title: string;
  ms: number;
  color: string;
}

export const stageColors: Record<string, string> = {
  embedding: "#0f6cbd",
  vector_search: "#107c10",
  generation: "#a4262c",
  cache: "#8764b8",
};

export function MetricTiles({ totalMs, stages }: { totalMs: number; stages: StageTiming[] }) {
  const styles = useStyles();
  const measured = stages.reduce((sum, s) => sum + s.ms, 0);
  const overhead = Math.max(totalMs - measured, 0);

  return (
    <div>
      <div className={styles.row}>
        <div className={styles.tile}>
          <Caption1 block>Total</Caption1>
          <div className={styles.value}>{totalMs} ms</div>
        </div>
        {stages.map((s) => (
          <div key={s.id} className={styles.tile}>
            <Caption1 block>{s.title}</Caption1>
            <div className={styles.value} style={{ color: s.color }}>{s.ms} ms</div>
          </div>
        ))}
      </div>

      <div className={styles.bar}>
        {stages.map((s) => (
          <div key={s.id} style={{ width: `${(s.ms / Math.max(totalMs, 1)) * 100}%`, backgroundColor: s.color }} />
        ))}
      </div>
      <div className={styles.legend}>
        {stages.map((s) => (
          <span key={s.id} className={styles.legendItem}>
            <span className={styles.swatch} style={{ backgroundColor: s.color }} />
            <Caption1>{`${s.title} ${Math.round((s.ms / Math.max(totalMs, 1)) * 100)}%`}</Caption1>
          </span>
        ))}
        {overhead > 0 && <Caption1>{`other ${overhead} ms`}</Caption1>}
      </div>
    </div>
  );
}

export function SectionHeading({ title, hint }: { title: string; hint?: string }) {
  return (
    <div style={{ marginBottom: 12 }}>
      <Title3 block>{title}</Title3>
      {hint && <Caption1 block>{hint}</Caption1>}
    </div>
  );
}

export function StatTile({ label, value, tone }: { label: string; value: string; tone?: string }) {
  const styles = useStyles();
  return (
    <div className={styles.tile}>
      <Caption1 block>{label}</Caption1>
      <div className={styles.value} style={tone ? { color: tone } : undefined}>{value}</div>
    </div>
  );
}

export function StatusBadge({ needsReview, reason, grounded, cacheHit, cacheAge }: {
  needsReview: boolean;
  reason: string;
  grounded?: boolean;
  cacheHit?: boolean;
  cacheAge?: number;
}) {
  return (
    <div style={{ display: "flex", gap: 8, flexWrap: "wrap", alignItems: "center" }}>
      <Badge appearance="filled" color={needsReview ? "warning" : "success"} size="large">
        {needsReview ? "Needs review" : "Translated"}
      </Badge>
      <Badge appearance="outline">{reason}</Badge>
      {grounded === false && (
        <Badge appearance="tint" color="danger">No history — unverified</Badge>
      )}
      {cacheHit && (
        <Badge appearance="tint" color="brand">
          {`Cached ${cacheAge !== undefined ? `${Math.round(cacheAge)}s ago` : ""}`}
        </Badge>
      )}
    </div>
  );
}

export function PanelTitle({ children }: { children: React.ReactNode }) {
  return <Subtitle2 block style={{ marginBottom: 8 }}>{children}</Subtitle2>;
}
