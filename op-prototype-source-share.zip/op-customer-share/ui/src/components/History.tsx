import { useEffect, useMemo, useState } from "react";
import {
  Badge,
  Button,
  Caption1,
  Divider,
  MessageBar,
  MessageBarBody,
  Table,
  TableBody,
  TableCell,
  TableHeader,
  TableHeaderCell,
  TableRow,
  Tooltip,
  makeStyles,
  shorthands,
  tokens,
} from "@fluentui/react-components";
import { ArrowClockwise20Regular, ArrowRepeatAll20Regular, Eye20Regular } from "@fluentui/react-icons";
import { RunResult, api } from "../api";
import { Prefill } from "./RunTest";
import { ArchitectureDiagram } from "./ArchitectureDiagram";
import { PanelTitle, SectionHeading, StatTile } from "./Metrics";

const useStyles = makeStyles({
  page: { display: "flex", flexDirection: "column", ...shorthands.gap("20px"), minWidth: 0 },
  headRow: {
    display: "flex",
    justifyContent: "space-between",
    alignItems: "start",
    flexWrap: "wrap",
    ...shorthands.gap("12px"),
  },
  tiles: { display: "flex", ...shorthands.gap("12px"), flexWrap: "wrap" },
  card: {
    ...shorthands.padding("8px", "16px", "16px"),
    ...shorthands.borderRadius(tokens.borderRadiusLarge),
    ...shorthands.border("1px", "solid", tokens.colorNeutralStroke2),
    backgroundColor: tokens.colorNeutralBackground1,
    boxShadow: tokens.shadow4,
    minWidth: 0,
    "@media (max-width: 600px)": { ...shorthands.padding("8px", "10px", "12px") },
  },
  scroller: { overflowX: "auto", maxWidth: "100%", ...shorthands.padding("0", "0", "4px") },
  table: { minWidth: "960px" },
  detail: {
    ...shorthands.padding("20px"),
    ...shorthands.borderRadius(tokens.borderRadiusLarge),
    ...shorthands.border("1px", "solid", tokens.colorNeutralStroke2),
    backgroundColor: tokens.colorNeutralBackground1,
    boxShadow: tokens.shadow8,
    minWidth: 0,
    "@media (max-width: 600px)": { ...shorthands.padding("14px") },
  },
  selectedRow: { backgroundColor: tokens.colorNeutralBackground1Selected },
  sig: { maxWidth: "320px", overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" },
  empty: {
    ...shorthands.padding("40px", "20px"),
    textAlign: "center",
    color: tokens.colorNeutralForeground3,
  },
  rowActions: { display: "flex", ...shorthands.gap("6px"), justifyContent: "end", flexWrap: "wrap" },
  scrollHint: { "@media (min-width: 901px)": { display: "none" } },
});

export function History({ onRerun }: { onRerun?: (prefill: Prefill) => void }) {
  const styles = useStyles();
  const [rows, setRows] = useState<RunResult[]>([]);
  const [selected, setSelected] = useState<RunResult | null>(null);
  const [error, setError] = useState<string | null>(null);

  function load() {
    api.history().then(setRows).catch((e) => setError(String(e)));
  }
  useEffect(load, []);

  const stats = useMemo(() => {
    if (rows.length === 0) return null;
    const avg = Math.round(rows.reduce((s, r) => s + (r.total_ms ?? 0), 0) / rows.length);
    const review = rows.filter((r) => r.needs_review).length;
    const fastest = Math.min(...rows.map((r) => r.total_ms ?? 0));
    const hits = rows.filter((r) => r.cache?.hit).length;
    return { total: rows.length, avg, review, fastest, hits };
  }, [rows]);

  const stageData = useMemo(() => {
    if (!selected?.trace) return undefined;
    return Object.fromEntries(
      selected.trace.map((s) => [s.id, { input: s.input, output: s.output, latency_ms: s.latency_ms }]),
    );
  }, [selected]);

  return (
    <div className={styles.page}>
      <div className={styles.headRow}>
        <SectionHeading title="Past tests" hint="Every run is stored in DocumentDB with its full trace." />
        <Button appearance="secondary" icon={<ArrowClockwise20Regular />} onClick={load}>
          Refresh
        </Button>
      </div>

      {error && (
        <MessageBar intent="error">
          <MessageBarBody>{error}</MessageBarBody>
        </MessageBar>
      )}

      {stats && (
        <div className={styles.tiles}>
          <StatTile label="Runs recorded" value={String(stats.total)} />
          <StatTile label="Average total" value={`${stats.avg} ms`} />
          <StatTile label="Fastest" value={`${stats.fastest} ms`} tone="#107c10" />
          <StatTile label="Cache hits" value={`${stats.hits} of ${stats.total}`} tone="#8764b8" />
          <StatTile label="Needed review" value={String(stats.review)} tone={stats.review ? "#a4262c" : undefined} />
        </div>
      )}

      <div className={styles.card}>
        {rows.length === 0 ? (
          <div className={styles.empty}>No tests run yet. Try one from the “Run a test” tab.</div>
        ) : (
          <>
            <Caption1 block className={styles.scrollHint} style={{ marginTop: 8 }}>
              Swipe the table sideways to see every column.
            </Caption1>
            <div className={styles.scroller}>
              <Table size="medium" className={styles.table}>
                <TableHeader>
                  <TableRow>
                    <TableHeaderCell>When</TableHeaderCell>
                    <TableHeaderCell>NDC</TableHeaderCell>
                    <TableHeaderCell>Doctor's SIG</TableHeaderCell>
                    <TableHeaderCell>Result</TableHeaderCell>
                    <TableHeaderCell>Cache</TableHeaderCell>
                    <TableHeaderCell>Layout</TableHeaderCell>
                    <TableHeaderCell>Total</TableHeaderCell>
                    <TableHeaderCell style={{ textAlign: "right" }}>Actions</TableHeaderCell>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {rows.map((r) => {
                    const req = r.request as Record<string, unknown>;
                    const isSelected = selected?.id === r.id;
                    return (
                      <TableRow key={r.id} className={isSelected ? styles.selectedRow : undefined}>
                        <TableCell>{(r.created_at ?? "").slice(0, 19).replace("T", " ")}</TableCell>
                        <TableCell>{String(req?.ndc ?? "")}</TableCell>
                        <TableCell>
                          <Tooltip content={String(req?.doctors_sig ?? "")} relationship="label">
                            <div className={styles.sig}>{String(req?.doctors_sig ?? "")}</div>
                          </Tooltip>
                        </TableCell>
                        <TableCell>
                          <Badge appearance="tint" color={r.needs_review ? "warning" : "success"}>
                            {r.needs_review ? r.reason : "translated"}
                          </Badge>
                        </TableCell>
                        <TableCell>
                          <Badge appearance="tint" color={r.cache?.hit ? "brand" : "informative"}>
                            {r.cache?.hit ? "hit" : "miss"}
                          </Badge>
                        </TableCell>
                        <TableCell><Badge appearance="outline">{r.layout}</Badge></TableCell>
                        <TableCell>{r.total_ms} ms</TableCell>
                        <TableCell>
                          <div className={styles.rowActions}>
                            <Button size="small" icon={<Eye20Regular />}
                                    onClick={() => api.runDetail(r.id).then(setSelected)}>
                              View flow
                            </Button>
                            {onRerun && (
                              <Button size="small" appearance="primary" icon={<ArrowRepeatAll20Regular />}
                                      onClick={() => onRerun({
                                        ndc: String(req?.ndc ?? ""),
                                        sig: String(req?.doctors_sig ?? ""),
                                        layout: r.layout || "baseline",
                                      })}>
                                Rerun
                              </Button>
                            )}
                          </div>
                        </TableCell>
                      </TableRow>
                    );
                  })}
                </TableBody>
              </Table>
            </div>
          </>
        )}
      </div>

      {selected && (
        <div className={styles.detail}>
          <PanelTitle>{`Flow for run ${selected.id.slice(0, 8)}`}</PanelTitle>
          <Caption1 block>
            {selected.caller ? `Run by ${selected.caller}` : ""}
            {selected.translated_sig ? ` · “${selected.translated_sig}”` : ""}
          </Caption1>
          <Divider style={{ marginTop: 14, marginBottom: 16 }} />
          <ArchitectureDiagram stageData={stageData} />
        </div>
      )}
    </div>
  );
}
