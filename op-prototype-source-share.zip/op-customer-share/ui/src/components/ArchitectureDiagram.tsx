import { useEffect, useState } from "react";
import {
  Badge,
  Body1,
  Button,
  Caption1,
  Subtitle2,
  Text,
  makeStyles,
  mergeClasses,
  shorthands,
  tokens,
} from "@fluentui/react-components";
import { Dismiss24Regular } from "@fluentui/react-icons";
import { toneColor } from "../architecture";
import {
  VIEW_H,
  VIEW_W,
  blockById,
  connectors,
  nodeById,
  nodes,
  zones,
} from "./diagramLayout";

const NARROW_QUERY = "(max-width: 900px)";

const useStyles = makeStyles({
  wrap: { position: "relative", width: "100%", minWidth: 0 },
  scroller: { width: "100%", overflowX: "auto", overflowY: "hidden", ...shorthands.padding("0", "0", "6px") },
  /** Below the breakpoint the SVG keeps a floor width and scrolls, so labels stay readable. */
  svg: { width: "100%", height: "auto", display: "block", minWidth: "900px" },
  hint: { "@media (min-width: 901px)": { display: "none" } },
  node: { cursor: "pointer" },
  detail: {
    position: "absolute",
    zIndex: 5,
    width: "380px",
    maxWidth: "min(380px, calc(100vw - 48px))",
    ...shorthands.padding("14px"),
    ...shorthands.borderRadius(tokens.borderRadiusLarge),
    ...shorthands.border("1px", "solid", tokens.colorNeutralStroke1),
    backgroundColor: tokens.colorNeutralBackground1,
    boxShadow: tokens.shadow28,
  },
  /** On phones the absolute card would land off-canvas, so dock it as a sheet instead. */
  detailSheet: {
    position: "fixed",
    zIndex: 20,
    left: "8px",
    right: "8px",
    bottom: "8px",
    top: "auto",
    width: "auto",
    maxWidth: "none",
    maxHeight: "72vh",
    overflowY: "auto",
  },
  detailHead: { display: "flex", justifyContent: "space-between", alignItems: "start", ...shorthands.gap("8px") },
  pre: {
    backgroundColor: tokens.colorNeutralBackground3,
    ...shorthands.padding("8px"),
    ...shorthands.borderRadius(tokens.borderRadiusSmall),
    maxHeight: "200px",
    overflowY: "auto",
    fontSize: "11px",
    whiteSpace: "pre-wrap",
    wordBreak: "break-word",
    marginTop: "4px",
  },
  badges: { display: "flex", ...shorthands.gap("6px"), marginTop: "8px", flexWrap: "wrap" },
});

function useIsNarrow() {
  const [narrow, setNarrow] = useState(
    () => typeof window !== "undefined" && window.matchMedia(NARROW_QUERY).matches,
  );
  useEffect(() => {
    const mq = window.matchMedia(NARROW_QUERY);
    const onChange = (e: MediaQueryListEvent) => setNarrow(e.matches);
    mq.addEventListener("change", onChange);
    return () => mq.removeEventListener("change", onChange);
  }, []);
  return narrow;
}

interface StageValue {
  input: unknown;
  output: unknown;
  latency_ms: number | null;
}

interface Props {
  stageData?: Record<string, StageValue>;
}

export function ArchitectureDiagram({ stageData }: Props) {
  const styles = useStyles();
  const isNarrow = useIsNarrow();
  const [selected, setSelected] = useState<string | null>(null);

  const node = selected ? nodeById.get(selected) : undefined;
  const block = selected ? blockById.get(selected) : undefined;
  const values = selected && stageData ? stageData[selected] : undefined;

  return (
    <div className={styles.wrap}>
      <Caption1 block className={styles.hint} style={{ marginBottom: 6 }}>
        Scroll the diagram sideways to follow the whole flow.
      </Caption1>
      <div className={styles.scroller}>
        <svg className={styles.svg} viewBox={`0 0 ${VIEW_W} ${VIEW_H}`} role="img">
        <defs>
          <marker id="arrow" viewBox="0 0 10 10" refX="9" refY="5" markerWidth="7" markerHeight="7"
                  orient="auto-start-reverse">
            <path d="M 0 0 L 10 5 L 0 10 z" fill={tokens.colorNeutralForeground3} />
          </marker>
          <filter id="soft" x="-20%" y="-20%" width="140%" height="140%">
            <feDropShadow dx="0" dy="2" stdDeviation="3" floodOpacity="0.16" />
          </filter>
        </defs>

        {zones.map((z) => (
          <g key={z.label}>
            <rect x={z.x} y={z.y} width={z.w} height={z.h} rx={14}
                  fill={z.accent} fillOpacity={0.05}
                  stroke={z.accent} strokeOpacity={0.35} strokeDasharray="6 4" />
            <text x={z.x + 12} y={z.y + 20} fontSize={12} fontWeight={600}
                  fill={z.accent} opacity={0.9}>{z.label}</text>
          </g>
        ))}

        {connectors.map((c) => (
          <g key={c.d}>
            <path d={c.d} fill="none" strokeWidth={2}
                  strokeDasharray={c.label ? "5 4" : undefined}
                  stroke={tokens.colorNeutralForeground3} markerEnd="url(#arrow)" />
            {c.label && (
              <text x={c.labelX} y={c.labelY} fontSize={11} fontWeight={600}
                    fill={tokens.colorNeutralForeground3}>{c.label}</text>
            )}
          </g>
        ))}

        {nodes.map((n) => {
          const b = blockById.get(n.id)!;
          const accent = toneColor[b.tone];
          const active = selected === n.id;
          const hasValues = Boolean(stageData?.[n.id]);
          return (
            <g key={n.id} className={styles.node} onClick={() => setSelected(n.id)} filter="url(#soft)">
              <rect x={n.x} y={n.y} width={n.w} height={n.h} rx={10}
                    fill={tokens.colorNeutralBackground1}
                    stroke={active ? accent : tokens.colorNeutralStroke1}
                    strokeWidth={active ? 2.5 : 1} />
              <rect x={n.x} y={n.y} width={4} height={n.h} rx={2} fill={accent} />
              <text x={n.x + 14} y={n.y + 26} fontSize={13} fontWeight={600}
                    fill={tokens.colorNeutralForeground1}>{b.title}</text>
              <text x={n.x + 14} y={n.y + 44} fontSize={11}
                    fill={tokens.colorNeutralForeground3}>{b.subtitle}</text>
              {hasValues && (
                <>
                  <circle cx={n.x + n.w - 14} cy={n.y + 16} r={5} fill="#107c10" />
                  <text x={n.x + 14} y={n.y + 58} fontSize={10} fill="#107c10" fontWeight={600}>
                    {`${stageData![n.id].latency_ms ?? 0} ms · click for values`}
                  </text>
                </>
              )}
            </g>
          );
        })}
        </svg>
      </div>

      {node && block && (
        <div
          className={isNarrow ? mergeClasses(styles.detail, styles.detailSheet) : styles.detail}
          style={
            isNarrow
              ? undefined
              : {
                  left: `${Math.min((node.x / VIEW_W) * 100, 62)}%`,
                  top: `${((node.y + node.h + 8) / VIEW_H) * 100}%`,
                }
          }
        >
          <div className={styles.detailHead}>
            <Subtitle2>{block.title}</Subtitle2>
            <Button appearance="subtle" size="small" icon={<Dismiss24Regular />}
                    onClick={() => setSelected(null)} aria-label="Close" />
          </div>
          <Caption1 block>{block.subtitle}</Caption1>
          <Body1 block style={{ marginTop: 8 }}>{block.detail}</Body1>
          {values && (
            <>
              <div className={styles.badges}>
                <Badge appearance="tint" color="success">{values.latency_ms ?? 0} ms</Badge>
              </div>
              <Text weight="semibold" block style={{ marginTop: 10 }}>Input</Text>
              <pre className={styles.pre}>{JSON.stringify(values.input, null, 2)}</pre>
              <Text weight="semibold" block style={{ marginTop: 8 }}>Output</Text>
              <pre className={styles.pre}>{JSON.stringify(values.output, null, 2)}</pre>
            </>
          )}
        </div>
      )}
    </div>
  );
}
