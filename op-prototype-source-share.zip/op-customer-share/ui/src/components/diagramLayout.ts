import { ArchBlock, architecture } from "../architecture";

export interface NodeLayout {
    id: string;
    x: number;
    y: number;
    w: number;
    h: number;
}

export interface ZoneLayout {
    label: string;
    x: number;
    y: number;
    w: number;
    h: number;
    accent: string;
}

export const VIEW_W = 1200;
export const VIEW_H = 400;

export const zones: ZoneLayout[] = [
    { label: "Client", x: 14, y: 54, w: 192, h: 124, accent: "#6264a7" },
    { label: "Azure Container Apps — FastAPI", x: 214, y: 54, w: 960, h: 124, accent: "#0f6cbd" },
    {
        label: "Cache miss path — retrieval and generation", x: 414, y: 216, w: 760, h: 124,
        accent: "#107c10"
    },
];

export const nodes: NodeLayout[] = [
    { id: "request", x: 24, y: 84, w: 170, h: 64 },
    { id: "auth", x: 224, y: 84, w: 170, h: 64 },
    { id: "cache", x: 424, y: 84, w: 170, h: 64 },
    { id: "response", x: 1004, y: 84, w: 170, h: 64 },
    { id: "embedding", x: 424, y: 246, w: 170, h: 64 },
    { id: "vector_search", x: 614, y: 246, w: 170, h: 64 },
    { id: "policy", x: 804, y: 246, w: 170, h: 64 },
    { id: "generation", x: 994, y: 246, w: 170, h: 64 },
];

export interface Connector {
    d: string;
    label?: string;
    labelX?: number;
    labelY?: number;
    dashed?: boolean;
}

// Drawn with distinct turn points so no two connectors overlap.
export const connectors: Connector[] = [
    { d: "M194,116 H218" },
    { d: "M394,116 H418" },
    { d: "M598,116 H998", label: "cache hit — skips all three stages", labelX: 620, labelY: 106 },
    { d: "M509,152 V240", label: "miss", labelX: 516, labelY: 200 },
    { d: "M594,278 H608" },
    { d: "M784,278 H798" },
    { d: "M974,278 H988" },
    { d: "M1089,242 V154" },
];

export const nodeById = new Map<string, NodeLayout>(nodes.map((n) => [n.id, n]));
export const blockById = new Map<string, ArchBlock>(architecture.map((b) => [b.id, b]));
