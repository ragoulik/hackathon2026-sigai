import { makeStyles, shorthands, tokens, Caption1, Title2 } from "@fluentui/react-components";

const OPTUM_ORANGE = "#FF612B";

const useStyles = makeStyles({
  bar: {
    display: "flex",
    alignItems: "center",
    ...shorthands.gap("16px"),
    minWidth: 0,
    "@media (max-width: 720px)": { ...shorthands.gap("10px") },
  },
  logo: { display: "flex", alignItems: "baseline", ...shorthands.gap("2px"), flexShrink: 0 },
  word: {
    fontSize: "28px",
    fontWeight: 700,
    letterSpacing: "-0.5px",
    color: OPTUM_ORANGE,
    "@media (max-width: 600px)": { fontSize: "22px" },
  },
  dot: { width: "7px", height: "7px", ...shorthands.borderRadius("50%"), backgroundColor: OPTUM_ORANGE },
  divider: {
    width: "1px",
    alignSelf: "stretch",
    backgroundColor: tokens.colorNeutralStroke2,
    "@media (max-width: 600px)": { display: "none" },
  },
  titles: { display: "flex", flexDirection: "column", minWidth: 0 },
  title: {
    overflowWrap: "anywhere",
    "@media (max-width: 900px)": { fontSize: "22px", lineHeight: "28px" },
    "@media (max-width: 600px)": { fontSize: "17px", lineHeight: "22px" },
  },
  tagline: { "@media (max-width: 600px)": { display: "none" } },
});

/** Text wordmark placeholder. Replace with the official Optum SVG asset if licensed. */
export function Brand() {
  const styles = useStyles();
  return (
    <div className={styles.bar}>
      <div className={styles.logo}>
        <span className={styles.word}>Optum</span>
        <span className={styles.dot} />
      </div>
      <div className={styles.divider} />
      <div className={styles.titles}>
        <Title2 className={styles.title}>Hackathon 2026 — SigAI Deduplication and more</Title2>
        <Caption1 className={styles.tagline}>
          Microsoft hackathon for Optum · vector search on Azure DocumentDB, grounded generation with Azure OpenAI
        </Caption1>
      </div>
    </div>
  );
}
