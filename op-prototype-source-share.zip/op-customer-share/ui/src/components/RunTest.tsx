import { useEffect, useMemo, useState } from "react";
import {
  Body1,
  Button,
  Caption1,
  Combobox,
  Divider,
  Dropdown,
  Field,
  MessageBar,
  MessageBarBody,
  Option,
  Spinner,
  Switch,
  Tag,
  Textarea,
  Tooltip,
  makeStyles,
  shorthands,
  tokens,
} from "@fluentui/react-components";
import { ArrowClockwise20Regular, Play20Filled } from "@fluentui/react-icons";
import { NdcOption, RunResult, api } from "../api";
import { ArchitectureDiagram } from "./ArchitectureDiagram";
import { CacheBanner, MetricTiles, PanelTitle, SectionHeading, StatusBadge, stageColors } from "./Metrics";

const useStyles = makeStyles({
  page: { display: "flex", flexDirection: "column", ...shorthands.gap("24px"), minWidth: 0 },
  card: {
    ...shorthands.padding("20px"),
    ...shorthands.borderRadius(tokens.borderRadiusLarge),
    ...shorthands.border("1px", "solid", tokens.colorNeutralStroke2),
    backgroundColor: tokens.colorNeutralBackground1,
    boxShadow: tokens.shadow4,
    minWidth: 0,
    "@media (max-width: 600px)": { ...shorthands.padding("14px") },
  },
  grid: {
    display: "grid",
    gridTemplateColumns: "minmax(0, 1fr) minmax(0, 220px)",
    ...shorthands.gap("16px"),
    alignItems: "start",
    "@media (max-width: 720px)": { gridTemplateColumns: "minmax(0, 1fr)" },
  },
  cell: { minWidth: 0 },
  /** Fluent v9 gives Combobox/Dropdown a 250px min-width, which overflows narrow grid tracks. */
  fluidInput: { minWidth: "0px", width: "100%" },
  full: { gridColumn: "1 / -1", minWidth: 0 },
  chips: { display: "flex", ...shorthands.gap("6px"), flexWrap: "wrap", marginTop: "8px" },
  chip: { cursor: "pointer", maxWidth: "100%" },
  actions: {
    display: "flex",
    ...shorthands.gap("10px"),
    alignItems: "center",
    flexWrap: "wrap",
    marginTop: "18px",
    paddingTop: "16px",
    borderTop: `1px solid ${tokens.colorNeutralStroke2}`,
  },
  hero: {
    ...shorthands.padding("20px"),
    ...shorthands.borderRadius(tokens.borderRadiusLarge),
    backgroundImage: `linear-gradient(135deg, ${tokens.colorNeutralBackground1}, ${tokens.colorNeutralBackground3})`,
    ...shorthands.border("1px", "solid", tokens.colorNeutralStroke2),
    boxShadow: tokens.shadow8,
    minWidth: 0,
    "@media (max-width: 600px)": { ...shorthands.padding("14px") },
  },
  heroText: {
    fontSize: "26px",
    fontWeight: 600,
    lineHeight: "34px",
    marginTop: "10px",
    overflowWrap: "anywhere",
    "@media (max-width: 600px)": { fontSize: "20px", lineHeight: "27px" },
  },
  inputEcho: { color: tokens.colorNeutralForeground3, fontStyle: "italic", overflowWrap: "anywhere" },
});

export interface Prefill {
  ndc: string;
  sig: string;
  layout: string;
}

export function RunTest({ prefill }: { prefill?: Prefill | null }) {
  const styles = useStyles();
  const [ndc, setNdc] = useState("");
  const [ndcQuery, setNdcQuery] = useState("");
  const [options, setOptions] = useState<NdcOption[]>([]);
  const [samples, setSamples] = useState<string[]>([]);
  const [sig, setSig] = useState("");
  const [layout, setLayout] = useState("baseline");
  const [busy, setBusy] = useState(false);
  const [useCache, setUseCache] = useState(true);
  const [result, setResult] = useState<RunResult | null>(null);
  const [error, setError] = useState<string | null>(null);

  function applyRandom() {
    api.randomNdc()
      .then((r) => {
        setNdc(r.ndc);
        setNdcQuery(r.ndc);
        setOptions([r]);
        setSamples(r.sample_sigs ?? []);
        if (r.sample_sigs?.length) setSig(r.sample_sigs[0]);
      })
      .catch((e) => setError(String(e)));
  }

  useEffect(() => {
    if (prefill) {
      setNdc(prefill.ndc);
      setNdcQuery(prefill.ndc);
      setSig(prefill.sig);
      setLayout(prefill.layout);
      setOptions([{ ndc: prefill.ndc, drug_name: "", drug_form: "" }]);
      setSamples([]);
      setResult(null);
      setError(null);
      return;
    }
    applyRandom();
  }, [prefill]);

  useEffect(() => {
    if (!ndcQuery || ndcQuery.length < 2) return;
    const timer = setTimeout(() => {
      api.searchNdcs(ndcQuery).then(setOptions).catch(() => undefined);
    }, 250);
    return () => clearTimeout(timer);
  }, [ndcQuery]);

  const stageData = useMemo(() => {
    if (!result) return undefined;
    return Object.fromEntries(
      result.trace.map((s) => [s.id, { input: s.input, output: s.output, latency_ms: s.latency_ms }]),
    );
  }, [result]);

  const timings = useMemo(() => {
    if (!result) return [];
    const names: Record<string, string> = {
      cache: "Cache lookup",
      embedding: "Embedding",
      vector_search: "Vector search",
      generation: "Generation",
    };
    // On a hit the trace still carries the original run's stage timings; charting them
    // against this run's total would overflow the bar and imply work that did not happen.
    const relevant = result.cache?.hit
      ? result.trace.filter((s) => s.id === "cache")
      : result.trace.filter((s) => s.id !== "cache");
    return relevant
      .filter((s) => stageColors[s.id])
      .map((s) => ({ id: s.id, title: names[s.id], ms: s.latency_ms ?? 0, color: stageColors[s.id] }));
  }, [result]);

  async function runTest() {
    setBusy(true);
    setError(null);
    setResult(null);
    try {
      setResult(await api.run({ ndc, doctors_sig: sig, rx_number: "demo" }, layout, useCache));
    } catch (e) {
      setError(String(e));
    } finally {
      setBusy(false);
    }
  }

  return (
    <div className={styles.page}>
      <div>
        <SectionHeading
          title="Run a test"
          hint="Synthetic, nonclinical data. Not for dispensing, dosage advice or patient care."
        />

        <div className={styles.card}>
          <div className={styles.grid}>
            <Field className={styles.cell} label="NDC" hint="Type digits to search NDCs loaded in DocumentDB">
              <Combobox
                className={styles.fluidInput}
                freeform
                value={ndcQuery}
                selectedOptions={ndc ? [ndc] : []}
                onInput={(e) => setNdcQuery((e.target as HTMLInputElement).value)}
                onOptionSelect={(_, data) => {
                  setNdc(data.optionValue ?? "");
                  setNdcQuery(data.optionValue ?? "");
                }}
              >
                {options.map((o) => (
                  <Option key={o.ndc} value={o.ndc} text={o.ndc}>
                    {`${o.ndc}${o.drug_name ? ` — ${o.drug_name}` : ""}`}
                  </Option>
                ))}
              </Combobox>
            </Field>

            <Field className={styles.cell} label="Storage layout" hint="sig_centric needs the migration to have run">
              <Dropdown
                className={styles.fluidInput}
                listbox={{ className: styles.fluidInput }}
                value={layout}
                selectedOptions={[layout]}
                onOptionSelect={(_, d) => setLayout(d.optionValue ?? "baseline")}
              >
                <Option value="baseline">baseline</Option>
                <Option value="sig_centric">sig_centric</Option>
              </Dropdown>
            </Field>

            <div className={styles.full}>
              <Field label="Doctor's SIG (provider SIG)">
                <Textarea
                  value={sig}
                  onChange={(_, d) => setSig(d.value)}
                  rows={3}
                  resize="vertical"
                  placeholder="take 1 tablet by oral route every day"
                />
              </Field>
              {samples.length > 0 && (
                <>
                  <Caption1 block style={{ marginTop: 10 }}>
                    Historical SIGs for this NDC — click to use
                  </Caption1>
                  <div className={styles.chips}>
                    {samples.map((s) => (
                      <Tooltip key={s} content={s} relationship="label">
                        <Tag size="small" className={styles.chip} onClick={() => setSig(s)}>
                          {s.length > 52 ? `${s.slice(0, 52)}…` : s}
                        </Tag>
                      </Tooltip>
                    ))}
                  </div>
                </>
              )}
            </div>
          </div>

          <div className={styles.actions}>
            <Button appearance="primary" icon={<Play20Filled />} onClick={runTest}
                    disabled={busy || !ndc || !sig}>
              {busy ? "Running…" : "Run test"}
            </Button>
            <Button appearance="secondary" icon={<ArrowClockwise20Regular />} onClick={applyRandom}
                    disabled={busy}>
              Random NDC
            </Button>
            <Switch checked={useCache} onChange={(_, d) => setUseCache(d.checked)}
                    label={useCache ? "Cache on (1 hour)" : "Cache bypassed"} />
            {busy && <Spinner size="tiny" label="Embedding, searching, generating…" />}
          </div>
        </div>
      </div>

      {error && (
        <MessageBar intent="error">
          <MessageBarBody>{error}</MessageBarBody>
        </MessageBar>
      )}

      {result && (
        <>
          <div className={styles.hero}>
            <CacheBanner hit={Boolean(result.cache?.hit)}
                         ageSeconds={result.cache?.age_seconds}
                         ttlSeconds={result.cache?.ttl_seconds} />
            <StatusBadge needsReview={result.needs_review} reason={result.reason}
                         grounded={result.grounded_in_history}
                         cacheHit={result.cache?.hit} cacheAge={result.cache?.age_seconds} />
            <Body1 block className={styles.inputEcho} style={{ marginTop: 12 }}>
              {`"${String((result.request as Record<string, unknown>)?.doctors_sig ?? "")}"`}
            </Body1>
            <div className={styles.heroText}>
              {result.translated_sig ?? "— no translation returned —"}
            </div>
            <Divider style={{ marginTop: 18, marginBottom: 18 }} />
            <MetricTiles totalMs={result.total_ms} stages={timings} />
          </div>

          <div className={styles.card}>
            <PanelTitle>Flow for this run</PanelTitle>
            <Caption1 block style={{ marginBottom: 14 }}>
              Click any stage to see its exact input and output, including the prompt sent to the model.
            </Caption1>
            <ArchitectureDiagram stageData={stageData} />
          </div>
        </>
      )}
    </div>
  );
}
