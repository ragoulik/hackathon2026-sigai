import React from "react";
import ReactDOM from "react-dom/client";
import { EventType, AuthenticationResult } from "@azure/msal-browser";
import { MsalProvider } from "@azure/msal-react";
import { FluentProvider, webLightTheme } from "@fluentui/react-components";
import { msalInstance } from "./authConfig";
import { App } from "./App";

async function bootstrap() {
  await msalInstance.initialize();

  const existing = msalInstance.getAllAccounts();
  if (existing.length > 0) msalInstance.setActiveAccount(existing[0]);

  msalInstance.addEventCallback((event) => {
    if (event.eventType === EventType.LOGIN_SUCCESS && event.payload) {
      msalInstance.setActiveAccount((event.payload as AuthenticationResult).account);
    }
  });

  ReactDOM.createRoot(document.getElementById("root")!).render(
    <React.StrictMode>
      <MsalProvider instance={msalInstance}>
        <FluentProvider theme={webLightTheme}>
          <App />
        </FluentProvider>
      </MsalProvider>
    </React.StrictMode>,
  );
}

void bootstrap();
