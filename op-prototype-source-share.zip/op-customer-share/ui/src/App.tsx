import { useState } from "react";
import {
  AuthenticatedTemplate,
  UnauthenticatedTemplate,
  useMsal,
} from "@azure/msal-react";
import {
  Body1,
  Button,
  Caption1,
  Tab,
  TabList,
  Title2,
  Title3,
  makeStyles,
  shorthands,
  tokens,
} from "@fluentui/react-components";
import { loginRequest } from "./authConfig";
import { Brand } from "./components/Brand";
import { ArchitectureDiagram } from "./components/ArchitectureDiagram";
import { RunTest, Prefill } from "./components/RunTest";
import { History } from "./components/History";

const useStyles = makeStyles({
  page: {
    ...shorthands.padding("24px"),
    maxWidth: "1400px",
    marginLeft: "auto",
    marginRight: "auto",
    minWidth: 0,
    "@media (max-width: 600px)": { ...shorthands.padding("14px", "12px", "28px") },
  },
  header: {
    display: "flex",
    justifyContent: "space-between",
    alignItems: "center",
    flexWrap: "wrap",
    marginBottom: "16px",
    ...shorthands.gap("16px"),
  },
  account: {
    textAlign: "right",
    minWidth: 0,
    "@media (max-width: 720px)": { textAlign: "left" },
  },
  username: { overflowWrap: "anywhere" },
  tabs: {
    marginBottom: "20px",
    borderBottom: `1px solid ${tokens.colorNeutralStroke2}`,
    overflowX: "auto",
    maxWidth: "100%",
  },
  banner: {
    ...shorthands.padding("10px", "14px"),
    ...shorthands.borderRadius(tokens.borderRadiusMedium),
    backgroundColor: tokens.colorNeutralBackground3,
    marginBottom: "20px",
  },
});

export function App() {
  const styles = useStyles();
  const { instance, accounts } = useMsal();
  const [tab, setTab] = useState("architecture");
  const [prefill, setPrefill] = useState<Prefill | null>(null);

  return (
    <div className={styles.page}>
      <div className={styles.header}>
        <Brand />
        <AuthenticatedTemplate>
          <div className={styles.account}>
            <Body1 block className={styles.username}>{accounts[0]?.username}</Body1>
            <Button size="small" appearance="subtle" onClick={() => instance.logoutPopup()}>
              Sign out
            </Button>
          </div>
        </AuthenticatedTemplate>
      </div>

      <UnauthenticatedTemplate>
        <div className={styles.banner}>
          <Title3 block>Sign in required</Title3>
          <Body1 block style={{ marginTop: 8, marginBottom: 12 }}>
            This demo is restricted to permitted Microsoft Entra users.
          </Body1>
          <Button appearance="primary" onClick={() => instance.loginPopup(loginRequest)}>
            Sign in with Microsoft
          </Button>
        </div>
      </UnauthenticatedTemplate>

      <AuthenticatedTemplate>
        <TabList
          className={styles.tabs}
          selectedValue={tab}
          onTabSelect={(_, d) => {
            if (d.value !== "run") setPrefill(null);
            setTab(d.value as string);
          }}
        >
          <Tab value="architecture">Architecture</Tab>
          <Tab value="run">Run a test</Tab>
          <Tab value="history">History</Tab>
        </TabList>

        {tab === "architecture" && (
          <div>
            <Title3 block>Current architecture flow</Title3>
            <Caption1 block style={{ marginBottom: 16 }}>
              Click any block to see what it does. Synthetic, nonclinical data only.
            </Caption1>
            <ArchitectureDiagram />
          </div>
        )}
        {tab === "run" && <RunTest prefill={prefill} />}
        {tab === "history" && (
          <History
            onRerun={(p) => {
              setPrefill(p);
              setTab("run");
            }}
          />
        )}
      </AuthenticatedTemplate>
    </div>
  );
}
