import { InteractionRequiredAuthError } from "@azure/msal-browser";
import { API_SCOPE, loginRequest, msalInstance } from "./authConfig";

async function token(): Promise<string> {
    const account = msalInstance.getActiveAccount() ?? msalInstance.getAllAccounts()[0];
    if (!account) throw new Error("not signed in");
    try {
        const result = await msalInstance.acquireTokenSilent({ scopes: [API_SCOPE], account });
        return result.accessToken;
    } catch (error) {
        if (error instanceof InteractionRequiredAuthError) {
            const result = await msalInstance.acquireTokenPopup(loginRequest);
            return result.accessToken;
        }
        throw error;
    }
}

async function call<T>(path: string, init?: RequestInit): Promise<T> {
    const accessToken = await token();
    const response = await fetch(path, {
        ...init,
        headers: {
            ...(init?.headers ?? {}),
            Authorization: `Bearer ${accessToken}`,
            "Content-Type": "application/json",
        },
    });
    if (!response.ok) {
        throw new Error(`${response.status} ${await response.text()}`);
    }
    return response.json() as Promise<T>;
}

export interface NdcOption {
    ndc: string;
    drug_name: string;
    drug_form: string;
    occurrences?: number;
    sample_sigs?: string[];
}

export interface TraceStage {
    id: string;
    title: string;
    input: Record<string, unknown>;
    output: Record<string, unknown>;
    latency_ms: number | null;
}

export interface RunResult {
    id: string;
    request: Record<string, unknown>;
    layout: string;
    policy: string;
    translated_sig: string | null;
    needs_review: boolean;
    reason: string;
    grounded_in_history?: boolean;
    cache?: { hit: boolean; age_seconds?: number; ttl_seconds?: number };
    total_ms: number;
    caller?: string;
    created_at?: string;
    trace: TraceStage[];
}

export const api = {
    me: () => call<{ caller: string }>("/v1/me"),
    randomNdc: () => call<NdcOption>("/v1/ndcs/random"),
    searchNdcs: (q: string) => call<NdcOption[]>(`/v1/ndcs?q=${encodeURIComponent(q)}&limit=10`),
    run: (body: Record<string, unknown>, layout: string, useCache = true) =>
        call<RunResult>(`/v1/demo/run?layout=${layout}&use_cache=${useCache}`,
            { method: "POST", body: JSON.stringify(body) }),
    history: () => call<RunResult[]>("/v1/runs?limit=50"),
    runDetail: (id: string) => call<RunResult>(`/v1/runs/${id}`),
};
