import { Configuration, PublicClientApplication } from "@azure/msal-browser";

function requiredSetting(name: "VITE_AZURE_CLIENT_ID" | "VITE_AZURE_TENANT_ID" | "VITE_API_SCOPE"): string {
    const value = import.meta.env[name]?.trim();
    if (!value) throw new Error(`${name} must be configured`);
    return value;
}

const SPA_CLIENT_ID = requiredSetting("VITE_AZURE_CLIENT_ID");
const TENANT_ID = requiredSetting("VITE_AZURE_TENANT_ID");
export const API_SCOPE = requiredSetting("VITE_API_SCOPE");

const configuration: Configuration = {
    auth: {
        clientId: SPA_CLIENT_ID,
        authority: `https://login.microsoftonline.com/${TENANT_ID}`,
        redirectUri: window.location.origin,
    },
    cache: { cacheLocation: "sessionStorage", storeAuthStateInCookie: false },
};

export const msalInstance = new PublicClientApplication(configuration);
export const loginRequest = { scopes: [API_SCOPE] };
