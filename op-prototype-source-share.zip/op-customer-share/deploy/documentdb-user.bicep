param clusterName string
param principalId string

resource cluster 'Microsoft.DocumentDB/mongoClusters@2025-09-01' existing = {
  name: clusterName
}

resource user 'Microsoft.DocumentDB/mongoClusters/users@2025-09-01' = {
  parent: cluster
  name: principalId
  properties: {
    identityProvider: {
      type: 'MicrosoftEntraID'
      properties: { principalType: 'ServicePrincipal' }
    }
    roles: [
      { db: 'admin', role: 'root' }
    ]
  }
}
