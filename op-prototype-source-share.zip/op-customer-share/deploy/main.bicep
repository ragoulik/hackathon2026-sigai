targetScope = 'resourceGroup'

@description('Azure region for all resources. Verify DocumentDB and Azure OpenAI availability in this region.')
param location string = resourceGroup().location

@description('Short lowercase prefix used to generate globally unique resource names.')
@minLength(3)
@maxLength(12)
param prefix string

@description('Administrator username for the DocumentDB cluster.')
param documentDbAdminUser string

@secure()
@description('Administrator password for the DocumentDB cluster. Supply at deployment time; never store it in a file.')
param documentDbAdminPassword string

@description('Entra tenant ID used to validate API tokens.')
param tenantId string

@description('Audience of the protected API, normally api://<API application client ID>.')
param apiAudience string

@description('Comma-separated Entra client IDs allowed to call the API.')
param allowedClientIds string

@description('Container image tag in the registry created by this template.')
param imageName string = 'sig-api:v1'

@description('Create the API and jobs. Set false for the first deployment, push the image, then redeploy with true.')
param deployWorkloads bool = false

@description('Azure OpenAI model deployment name used by the application.')
param openAiDeploymentName string = 'sig-gpt4o'

@description('Azure OpenAI model name.')
param openAiModelName string = 'gpt-4o'

@description('Azure OpenAI model version available in the selected region.')
param openAiModelVersion string

var suffix = uniqueString(resourceGroup().id)
var registryName = toLower('acr00${prefix}${suffix}')
var documentDbName = '${prefix}-docdb-${take(suffix, 6)}'
var environmentName = '${prefix}-env'
var apiName = '${prefix}-api'
var jobsIdentityName = '${prefix}-jobs-id'
var apiIdentityName = '${prefix}-api-id'
var workspaceName = '${prefix}-logs'
var openAiName = '${prefix}-openai-${take(suffix, 6)}'
var mongoUri = 'mongodb+srv://${documentDbName}.mongocluster.cosmos.azure.com/?tls=true&authMechanism=MONGODB-OIDC&retrywrites=false&maxIdleTimeMS=120000'
var acrPullRoleId = subscriptionResourceId('Microsoft.Authorization/roleDefinitions', '7f951dda-4ed3-4680-a7ca-43fe172d538d')
var openAiUserRoleId = subscriptionResourceId('Microsoft.Authorization/roleDefinitions', '5e0bd9bd-7b93-4f28-af87-19fc36ad61bd')

resource registry 'Microsoft.ContainerRegistry/registries@2023-07-01' = {
  name: registryName
  location: location
  sku: { name: 'Basic' }
  properties: { adminUserEnabled: false }
}

resource workspace 'Microsoft.OperationalInsights/workspaces@2022-10-01' = {
  name: workspaceName
  location: location
  properties: {
    retentionInDays: 30
    features: { enableLogAccessUsingOnlyResourcePermissions: true }
    sku: { name: 'PerGB2018' }
  }
}

resource environment 'Microsoft.App/managedEnvironments@2024-03-01' = {
  name: environmentName
  location: location
  properties: {
    appLogsConfiguration: {
      destination: 'log-analytics'
      logAnalyticsConfiguration: {
        customerId: workspace.properties.customerId
        sharedKey: workspace.listKeys().primarySharedKey
      }
    }
  }
}

resource apiIdentity 'Microsoft.ManagedIdentity/userAssignedIdentities@2023-01-31' = {
  name: apiIdentityName
  location: location
}

resource jobsIdentity 'Microsoft.ManagedIdentity/userAssignedIdentities@2023-01-31' = {
  name: jobsIdentityName
  location: location
}

resource documentDb 'Microsoft.DocumentDB/mongoClusters@2025-09-01' = {
  name: documentDbName
  location: location
  properties: {
    administrator: {
      userName: documentDbAdminUser
      password: documentDbAdminPassword
    }
    serverVersion: '7.0'
    storage: { sizeGb: 256 }
    compute: { tier: 'M30' }
    sharding: { shardCount: 1 }
    highAvailability: { targetMode: 'Disabled' }
    publicNetworkAccess: 'Enabled'
  }
}

module jobsDbUser 'documentdb-user.bicep' = {
  name: 'jobs-documentdb-user'
  params: {
    clusterName: documentDb.name
    principalId: jobsIdentity.properties.principalId
  }
}

module apiDbUser 'documentdb-user.bicep' = {
  name: 'api-documentdb-user'
  params: {
    clusterName: documentDb.name
    principalId: apiIdentity.properties.principalId
  }
}

resource openAi 'Microsoft.CognitiveServices/accounts@2024-10-01' = {
  name: openAiName
  location: location
  kind: 'OpenAI'
  sku: { name: 'S0' }
  properties: {
    customSubDomainName: openAiName
    publicNetworkAccess: 'Enabled'
  }
}

resource modelDeployment 'Microsoft.CognitiveServices/accounts/deployments@2024-10-01' = {
  parent: openAi
  name: openAiDeploymentName
  sku: {
    name: 'GlobalStandard'
    capacity: 10
  }
  properties: {
    model: {
      format: 'OpenAI'
      name: openAiModelName
      version: openAiModelVersion
    }
    versionUpgradeOption: 'OnceNewDefaultVersionAvailable'
  }
}

resource apiAcrPull 'Microsoft.Authorization/roleAssignments@2022-04-01' = {
  name: guid(registry.id, apiIdentity.id, acrPullRoleId)
  scope: registry
  properties: {
    principalId: apiIdentity.properties.principalId
    principalType: 'ServicePrincipal'
    roleDefinitionId: acrPullRoleId
  }
}

resource jobsAcrPull 'Microsoft.Authorization/roleAssignments@2022-04-01' = {
  name: guid(registry.id, jobsIdentity.id, acrPullRoleId)
  scope: registry
  properties: {
    principalId: jobsIdentity.properties.principalId
    principalType: 'ServicePrincipal'
    roleDefinitionId: acrPullRoleId
  }
}

resource apiOpenAiUser 'Microsoft.Authorization/roleAssignments@2022-04-01' = {
  name: guid(openAi.id, apiIdentity.id, openAiUserRoleId)
  scope: openAi
  properties: {
    principalId: apiIdentity.properties.principalId
    principalType: 'ServicePrincipal'
    roleDefinitionId: openAiUserRoleId
  }
}

resource api 'Microsoft.App/containerApps@2024-03-01' = if (deployWorkloads) {
  name: apiName
  location: location
  identity: {
    type: 'UserAssigned'
    userAssignedIdentities: { '${apiIdentity.id}': {} }
  }
  properties: {
    managedEnvironmentId: environment.id
    configuration: {
      activeRevisionsMode: 'Single'
      ingress: {
        external: true
        targetPort: 8000
        transport: 'auto'
      }
      registries: [
        { server: registry.properties.loginServer, identity: apiIdentity.id }
      ]
    }
    template: {
      containers: [
        {
          name: 'api'
          image: '${registry.properties.loginServer}/${imageName}'
          resources: { cpu: json('2.0'), memory: '4Gi' }
          env: [
            { name: 'MONGO_URI', value: mongoUri }
            { name: 'MONGO_ENTRA_CREDENTIAL', value: 'default' }
            { name: 'AZURE_CLIENT_ID', value: apiIdentity.properties.clientId }
            { name: 'AZURE_TENANT_ID', value: tenantId }
            { name: 'API_AUDIENCE', value: apiAudience }
            { name: 'ALLOWED_CLIENT_IDS', value: allowedClientIds }
            { name: 'AZURE_OPENAI_ENDPOINT', value: openAi.properties.endpoint }
            { name: 'AZURE_OPENAI_DEPLOYMENT', value: openAiDeploymentName }
          ]
        }
      ]
      scale: { minReplicas: 1, maxReplicas: 3 }
    }
  }
  dependsOn: [apiAcrPull, apiOpenAiUser, apiDbUser, modelDeployment]
}

var jobs = [
  {
    name: '${prefix}-generate'
    cpu: json('4.0')
    memory: '8Gi'
    timeout: 10800
    command: ['python', '-m', 'sig_mvp.generate', '--occurrences', '100000', '--ndcs', '2000', '--unique-ratio', '0.30', '--batch-size', '64', '--drop']
  }
  {
    name: '${prefix}-migrate'
    cpu: json('2.0')
    memory: '4Gi'
    timeout: 7200
    command: ['python', '-m', 'sig_mvp.migrate', '--restart']
  }
  {
    name: '${prefix}-bench'
    cpu: json('2.0')
    memory: '4Gi'
    timeout: 1800
    command: ['python', '-m', 'sig_mvp.bench', '--probes', '50']
  }
]

resource containerJobs 'Microsoft.App/jobs@2024-03-01' = [for job in jobs: if (deployWorkloads) {
  name: job.name
  location: location
  identity: {
    type: 'UserAssigned'
    userAssignedIdentities: { '${jobsIdentity.id}': {} }
  }
  properties: {
    environmentId: environment.id
    configuration: {
      triggerType: 'Manual'
      replicaTimeout: job.timeout
      replicaRetryLimit: 0
      manualTriggerConfig: { parallelism: 1, replicaCompletionCount: 1 }
      registries: [
        { server: registry.properties.loginServer, identity: jobsIdentity.id }
      ]
    }
    template: {
      containers: [
        {
          name: job.name
          image: '${registry.properties.loginServer}/${imageName}'
          command: job.command
          resources: { cpu: job.cpu, memory: job.memory }
          env: [
            { name: 'MONGO_URI', value: mongoUri }
            { name: 'MONGO_ENTRA_CREDENTIAL', value: 'default' }
            { name: 'AZURE_CLIENT_ID', value: jobsIdentity.properties.clientId }
            { name: 'HF_HUB_OFFLINE', value: '1' }
            { name: 'TRANSFORMERS_OFFLINE', value: '1' }
          ]
        }
      ]
    }
  }
  dependsOn: [jobsAcrPull, jobsDbUser]
}]

output registryName string = registry.name
output registryLoginServer string = registry.properties.loginServer
output documentDbClusterName string = documentDb.name
output apiName string = apiName
output apiUrl string = deployWorkloads ? 'https://${api!.properties.configuration.ingress.fqdn}' : ''
output jobsIdentityClientId string = jobsIdentity.properties.clientId
output apiIdentityClientId string = apiIdentity.properties.clientId
output openAiEndpoint string = openAi.properties.endpoint
