# SIG Storage Deduplication Demo

This repository is a customer-shareable copy of the SIG demo. It contains no
credentials, connection strings, subscription IDs, tenant IDs, application IDs,
or personal account names. All environment-specific values must be supplied by
the deploying organization.

## Prerequisites

Install these tools before starting:

1. Git (only needed if the repository is delivered through source control).
2. Python 3.12.
3. Node.js 20 and npm.
4. Docker Desktop or another Docker-compatible build engine.
5. Azure CLI with the Container Apps extension: `az extension add --name containerapp --upgrade`.
6. Bicep CLI through Azure CLI: `az bicep install`.
7. An Azure subscription where you can create resources and role assignments.
8. Permission to create two Microsoft Entra app registrations.

The Azure region must support Azure DocumentDB Mongo clusters and the selected
Azure OpenAI model. Resource providers may need registration:

```powershell
az provider register --namespace Microsoft.App
az provider register --namespace Microsoft.ContainerRegistry
az provider register --namespace Microsoft.CognitiveServices
az provider register --namespace Microsoft.DocumentDB
az provider register --namespace Microsoft.ManagedIdentity
az provider register --namespace Microsoft.OperationalInsights
```

## 1. Create the Entra applications

In the Microsoft Entra admin center, create:

1. An API app registration. Expose one delegated scope such as `access_as_user`.
   Record its application client ID and Application ID URI (`api://<client-id>`).
2. A single-page application registration. Add `http://localhost:5173` as a SPA
   redirect URI for local development, grant the API delegated scope, and record
   the SPA application client ID.
3. Pre-authorize the SPA for the API scope or grant tenant admin consent according
   to your organization's policy.

No client secret is required. The deployed API and jobs use managed identities.

## 2. Install local dependencies

Dependencies are not included or preinstalled in this folder. From the repository
root, create an isolated Python environment and install them:

```powershell
py -3.12 -m venv .venv
.\.venv\Scripts\Activate.ps1
python -m pip install --upgrade pip
pip install --index-url https://download.pytorch.org/whl/cpu torch
pip install -r requirements.txt
npm --prefix ui install
```

## 3. Configure local development

Set configuration only in the current shell. Do not commit these values:

```powershell
$env:PYTHONPATH = "$PWD\src"
$env:AZURE_TENANT_ID = '<tenant-id>'
$env:API_AUDIENCE = 'api://<api-client-id>'
$env:ALLOWED_CLIENT_IDS = '<spa-client-id>'
$env:VITE_AZURE_TENANT_ID = $env:AZURE_TENANT_ID
$env:VITE_AZURE_CLIENT_ID = '<spa-client-id>'
$env:VITE_API_SCOPE = 'api://<api-client-id>/access_as_user'
```

For local Azure OpenAI access, sign in with `az login` and set:

```powershell
$env:AZURE_OPENAI_ENDPOINT = 'https://<resource-name>.openai.azure.com/'
$env:AZURE_OPENAI_DEPLOYMENT = '<deployment-name>'
$env:AZURE_OPENAI_CREDENTIAL = 'azure-cli'
```

For DocumentDB, use either an Entra OIDC URI or a native connection string kept
only in the shell. Example Entra configuration:

```powershell
$env:MONGO_URI = 'mongodb+srv://<cluster>.mongocluster.cosmos.azure.com/?tls=true&authMechanism=MONGODB-OIDC&retrywrites=false'
$env:MONGO_ENTRA_CREDENTIAL = 'azure-cli'
python -m sig_mvp.database
```

Run the API and UI in separate shells after setting the same values:

```powershell
uvicorn sig_mvp.api:app --host 127.0.0.1 --port 8000
npm --prefix ui run dev
```

## 4. Validate the source

```powershell
python -m compileall -q src tests
python -m unittest discover -s tests
npm --prefix ui run build
az bicep build --file deploy/main.bicep
```

## 5. Create Azure infrastructure

Sign in, select the target subscription without writing its ID into this repository,
and create a resource group:

```powershell
az login --tenant '<tenant-id>'
az account set --subscription '<subscription-name-or-id>'
az group create --name '<resource-group>' --location '<region>'
```

Copy `deploy/main.parameters.example.json` to a temporary file outside the repository
and replace every placeholder, including the DocumentDB password, immediately before
deployment. Delete that private file when both deployments are complete. The first
deployment creates infrastructure but not workloads because the registry is empty:

```powershell
az deployment group create `
  --resource-group '<resource-group>' `
  --template-file deploy/main.bicep `
  --parameters '@<path-to-private-parameters.json>' `
  --parameters deployWorkloads=false
```

The template creates Azure Container Registry, Log Analytics, Container Apps
environment, managed identities and role assignments, DocumentDB, Azure OpenAI,
and the model deployment. Its outputs contain the generated resource names.

## 6. Build and push the application image

Read the registry name from the deployment output, then build in ACR. The build
arguments are public application configuration, not credentials:

```powershell
$acr = az deployment group show --resource-group '<resource-group>' --name 'main' --query properties.outputs.registryName.value -o tsv
az acr build --registry $acr --image sig-api:v1 `
  --build-arg VITE_AZURE_CLIENT_ID='<spa-client-id>' `
  --build-arg VITE_AZURE_TENANT_ID='<tenant-id>' `
  --build-arg VITE_API_SCOPE='api://<api-client-id>/access_as_user' .
```

## 7. Deploy the API and jobs

Repeat the deployment with workloads enabled:

```powershell
az deployment group create `
  --resource-group '<resource-group>' `
  --template-file deploy/main.bicep `
  --parameters '@<path-to-private-parameters.json>' `
  --parameters deployWorkloads=true imageName='sig-api:v1'
```

Add the deployed API URL to the SPA app registration's redirect URIs. Obtain it with:

```powershell
az deployment group show --resource-group '<resource-group>' --name 'main' --query properties.outputs.apiUrl.value -o tsv
```

## 8. Load and prepare demo data

The included `data` directory contains synthetic demo data. Start the generation
job for a generated corpus, or load the included corpus locally after configuring
`MONGO_URI`:

```powershell
python -m sig_mvp.load --data data --drop
python -m sig_mvp.migrate --restart
```

For Azure jobs, use the generated job names:

```powershell
az containerapp job start --resource-group '<resource-group>' --name '<prefix>-generate'
az containerapp job start --resource-group '<resource-group>' --name '<prefix>-migrate'
az containerapp job start --resource-group '<resource-group>' --name '<prefix>-bench'
```

## 9. Verify and operate

Check the API endpoints after deployment:

```text
GET /healthz
GET /readyz
```

All data endpoints require a bearer token issued for the configured API audience.
Use Azure Monitor and the Log Analytics workspace for application and job logs.

## Security notes

- Never commit `.env`, private parameter files, access tokens, passwords, API keys,
  connection strings, generated data, or exported Azure configurations.
- Prefer managed identity for DocumentDB, ACR, and Azure OpenAI access.
- Restrict public network access and configure private endpoints/firewall rules to
  meet the customer's security policy before production use.
- This repository and its included data are for a synthetic, nonclinical demo.